package com.example.backend.db.entities;

public class KomentarDTO {

    private String korisnickoIme;
    private String komentar;
    private int ocena;

    public KomentarDTO(String korisnickoIme, String komentar, int ocena) {
        this.komentar = komentar;
        this.korisnickoIme = korisnickoIme;
        this.ocena = ocena;
    }

    public String getKorisnickoIme() {
        return korisnickoIme;
    }

    public void setKorisnickoIme(String korisnickoIme) {
        this.korisnickoIme = korisnickoIme;
    }

    public String getKomentar() {
        return komentar;
    }

    public void setKomentar(String komentar) {
        this.komentar = komentar;
    }

    public int getOcena() {
        return ocena;
    }

    public void setOcena(int ocena) {
        this.ocena = ocena;
    }

}
