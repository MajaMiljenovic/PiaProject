package com.example.backend.controllers;

import java.io.IOException;
import java.util.List;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.example.backend.db.dao.RandomRepo;
import com.example.backend.db.dao.VikendicaRepo;
import com.example.backend.db.entities.KomentarDTO;
import com.example.backend.db.entities.Slika;
import com.example.backend.db.entities.Vikendica;



@RestController
@RequestMapping("/vikendica")
@CrossOrigin(origins = "http://localhost:4200")
public class VikendicaController {
    
    @GetMapping("/get-all-vikendice")
    public List<Vikendica> getAllVikendice(@RequestParam String select, @RequestParam String naziv, @RequestParam String mesto) {
        return new VikendicaRepo().getAllVikendice(select, naziv, mesto);
    }

    @GetMapping("/get-vikendica/{idVikendice}")
    public Vikendica getVikendica(@PathVariable int idVikendice) {
        return new VikendicaRepo().getVikendica(idVikendice);
    }

    @PostMapping("/obrisi-vikendicu")
    public int obrisiVikendicu(@RequestBody int idVikendice) {
        return new VikendicaRepo().obrisiVikendicu(idVikendice);
    }
    

    @GetMapping("/get-all-slike/{idVikendice}")
    public List<Slika> getAllSlike(@PathVariable int idVikendice) {
        return new VikendicaRepo().getAllSlike(idVikendice);
    }

    @GetMapping("/get-all-komentari/{idVikendice}")
    public List<KomentarDTO> getAllKomentari(@PathVariable int idVikendice) {
        return new RandomRepo().getAllKomentari(idVikendice);
    }

    @GetMapping("/update-ocena/{idVikendice}")
    public float updateOcena(@PathVariable int idVikendice) {
        return new VikendicaRepo().updateOcena(idVikendice);
    }

    @GetMapping("/get-moje-vikendice")
    public List<Vikendica> getMojeVikendice(@RequestParam String korisnickoIme) {
        return new VikendicaRepo().getMojeVikendice(korisnickoIme);
    }

    @PostMapping("/update-naziv")
    public int updateNaziv(@RequestParam int idVikendice, @RequestParam String naziv){
        return new VikendicaRepo().updateNaziv(idVikendice, naziv);
    }
    
    @PostMapping("/update-mesto")
    public int updateMesto(@RequestParam int idVikendice, @RequestParam String mesto){
        return new VikendicaRepo().updateMesto(idVikendice, mesto);
    }

    @PostMapping("/update-opis")
    public int updateOpis(@RequestParam int idVikendice, @RequestParam String opis){
        return new VikendicaRepo().updateOpis(idVikendice, opis);
    }

    @PostMapping("/update-cenaLeto")
    public int updateCenaLeto(@RequestParam int idVikendice, @RequestParam int cenaLeto){
        return new VikendicaRepo().updateCenaLeto(idVikendice, cenaLeto);
    }

    @PostMapping("/update-cenaZima")
    public int updateCenaZima(@RequestParam int idVikendice, @RequestParam int cenaZima){
        return new VikendicaRepo().updateCenaZima(idVikendice, cenaZima);
    }

    @PostMapping("/update-telefon")
    public int updateTelefon(@RequestParam int idVikendice, @RequestParam String telefon){
        return new VikendicaRepo().updateTelefon(idVikendice, telefon);
    }

    @PostMapping("/update-lat")
    public int updateLat(@RequestParam int idVikendice, @RequestParam int lat){
        return new VikendicaRepo().updateLat(idVikendice, lat);
    }

    @PostMapping("/update-lng")
    public int updateLng(@RequestParam int idVikendice, @RequestParam int lng){
        return new VikendicaRepo().updateLng(idVikendice, lng);
    }

    @PostMapping("/insert-vikendica")
    public int insertVikendica(@RequestBody Vikendica vikendica) {
        return new VikendicaRepo().insertVikendica(vikendica);
    }

    @PostMapping("/insert-galerija")
    public int insertGalerija(@RequestParam int idVikendice, @RequestParam MultipartFile[] slike) throws IOException {
        int i = 0;
        for (MultipartFile file : slike) {
            i = i + new VikendicaRepo().insertSlika(idVikendice, file.getBytes());
        }
        return i;
    }

    @PostMapping("/delete-slika")
    public int deleteSlika(@RequestBody Slika slika) {
        return new VikendicaRepo().deleteSlika(slika);
    }
    
}
