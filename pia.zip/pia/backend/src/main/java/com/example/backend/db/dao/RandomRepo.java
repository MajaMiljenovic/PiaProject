package com.example.backend.db.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import com.example.backend.db.DB;
import com.example.backend.db.entities.KomentarDTO;
import com.example.backend.db.entities.PodaciDTO;

public class RandomRepo {
    
    public PodaciDTO getAllPodaci() {
        try(
            Connection conn = DB.source().getConnection();
            PreparedStatement stmt1 = conn.prepareStatement("select count(*) from vikendice");
            PreparedStatement stmt2 = conn.prepareStatement("select count(*) from korisnici where tip='vlasnik' and aktivan='da'");
            PreparedStatement stmt3 = conn.prepareStatement("select count(*) from korisnici where tip='turista' and aktivan='da'");
            PreparedStatement stmt4 = conn.prepareStatement("select count(*) from rezervacije where vremeRezervacije>? and vremeRezervacije<=?");
            PreparedStatement stmt5 = conn.prepareStatement("select count(*) from rezervacije where vremeRezervacije>? and vremeRezervacije<=?");
            PreparedStatement stmt6 = conn.prepareStatement("select count(*) from rezervacije where vremeRezervacije>? and vremeRezervacije<=?");

        ) {
            LocalDateTime pre24 = LocalDateTime.now().minusHours(24);
            stmt4.setTimestamp(1, Timestamp.valueOf(pre24));
            stmt4.setTimestamp(2, Timestamp.valueOf(LocalDateTime.now()));

            LocalDateTime pre7 = LocalDateTime.now().minusDays(7);
            stmt5.setTimestamp(1, Timestamp.valueOf(pre7));
            stmt5.setTimestamp(2, Timestamp.valueOf(pre24));

            LocalDateTime pre30 = LocalDateTime.now().minusDays(30);
            stmt6.setTimestamp(1, Timestamp.valueOf(pre30));
            stmt6.setTimestamp(2, Timestamp.valueOf(pre7));

            ResultSet rs1 = stmt1.executeQuery();
            ResultSet rs2 = stmt2.executeQuery();
            ResultSet rs3 = stmt3.executeQuery();
            ResultSet rs4 = stmt4.executeQuery();
            ResultSet rs5 = stmt5.executeQuery();
            ResultSet rs6 = stmt6.executeQuery();

            if(rs1.next() && rs2.next() && rs3.next() && rs4.next() && rs5.next() && rs6.next()){
                return new PodaciDTO(
                    rs1.getInt(1),
                    rs2.getInt(1),
                    rs3.getInt(1),
                    rs4.getInt(1),
                    rs5.getInt(1),
                    rs6.getInt(1)
                );
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public List<KomentarDTO> getAllKomentari(int idVikendice) {
        try (
            Connection conn = DB.source().getConnection();
            PreparedStatement stmt = conn.prepareStatement("select korisnickoImeTuriste, komentar, ocena from rezervacije where idVikendice=?");
        ) {
            stmt.setInt(1, idVikendice);
            ResultSet rs = stmt.executeQuery();
            KomentarDTO komentar;
            List<KomentarDTO> komentari = new ArrayList<>();
            while(rs.next()){
                komentar = new KomentarDTO(
                    rs.getString("korisnickoImeTuriste"),
                    rs.getString("komentar"),
                    rs.getInt("ocena")
                );
                komentari.add(komentar);
            }
            return komentari;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
}
