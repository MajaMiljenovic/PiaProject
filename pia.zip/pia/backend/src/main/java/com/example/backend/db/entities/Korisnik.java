package com.example.backend.db.entities;

public class Korisnik {
    
    private String korisnickoIme;
    private String lozinka;
    private String ime;
    private String prezime;
    private String pol;
    private String adresa;
    private String telefon;
    private String mejl;
    private byte[] slika;
    private String kartica;
    private String tip;
    private String aktivan;

    public Korisnik() {}

    public Korisnik(
        String korisnickoIme,
        String lozinka,
        String ime,
        String prezime, 
        String pol, 
        String adresa, 
        String telefon, 
        String mejl, 
        byte[] slika,
        String kartica, 
        String tip, 
        String aktivan
    ) {
        this.adresa = adresa;
        this.ime = ime;
        this.kartica = kartica;
        this.korisnickoIme = korisnickoIme;
        this.lozinka = lozinka;
        this.mejl = mejl;
        this.pol = pol;
        this.prezime = prezime;
        this.slika = slika;
        this.telefon = telefon;
        this.tip = tip;
        this.aktivan = aktivan;
    }

    public Korisnik(Korisnik korisnik){
        this.adresa = korisnik.adresa;
        this.ime = korisnik.ime;
        this.kartica = korisnik.kartica;
        this.korisnickoIme = korisnik.korisnickoIme;
        this.lozinka = korisnik.lozinka;
        this.mejl = korisnik.mejl;
        this.pol = korisnik.pol;
        this.prezime = korisnik.prezime;
        this.slika = korisnik.slika;
        this.telefon = korisnik.telefon;
        this.tip = korisnik.tip;
        this.aktivan = korisnik.aktivan;
    }

    public String getKorisnickoIme() {
        return korisnickoIme;
    }

    public void setKorisnickoIme(String korisnickoIme) {
        this.korisnickoIme = korisnickoIme;
    }

    public String getLozinka() {
        return lozinka;
    }

    public void setLozinka(String lozinka) {
        this.lozinka = lozinka;
    }

    public String getIme() {
        return ime;
    }

    public void setIme(String ime) {
        this.ime = ime;
    }

    public String getPrezime() {
        return prezime;
    }

    public void setPrezime(String prezime) {
        this.prezime = prezime;
    }

    public String getPol() {
        return pol;
    }

    public void setPol(String pol) {
        this.pol = pol;
    }

    public String getAdresa() {
        return adresa;
    }

    public void setAdresa(String adresa) {
        this.adresa = adresa;
    }

    public String getTelefon() {
        return telefon;
    }

    public void setTelefon(String telefon) {
        this.telefon = telefon;
    }

    public String getMejl() {
        return mejl;
    }

    public void setMejl(String mejl) {
        this.mejl = mejl;
    }

    public String getKartica() {
        return kartica;
    }

    public void setKartica(String kartica) {
        this.kartica = kartica;
    }

    public String getTip() {
        return tip;
    }

    public void setTip(String tip) {
        this.tip = tip;
    }

    public byte[] getSlika() {
        return slika;
    }

    public void setSlika(byte[] slika) {
        this.slika = slika;
    }

    public String getAktivan() {
        return aktivan;
    }

    public void setAktivan(String aktivan) {
        this.aktivan = aktivan;
    }


}
