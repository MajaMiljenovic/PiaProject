package com.example.backend.db.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.example.backend.db.DB;
import com.example.backend.db.entities.Administrator;
import com.example.backend.db.entities.PasswordUtils;

public class AdminRepo {

    public Administrator loginAdministrator(String korisnickoIme, String lozinka) {
        try(
            Connection conn = DB.source().getConnection();
            PreparedStatement stmt = conn.prepareStatement("select * from administratori where korisnickoIme=?");
        ) { 

            stmt.setString(1, korisnickoIme);
            ResultSet rs = stmt.executeQuery();
            if(rs.next()){
                if(PasswordUtils.checkPassword(lozinka, rs.getString(2))){
                    return new Administrator(
                    rs.getString(1),
                    rs.getString(2),
                    rs.getString(3),
                    rs.getString(4),
                    rs.getString(5)
                );
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public Administrator changeLozinkaAdmin(String korisnickoIme, String staraLozinka, String novaLozinka) {
        try (
            Connection conn = DB.source().getConnection();
            PreparedStatement stmt1 = conn.prepareStatement("select * from administratori where korisnickoIme=?");
            PreparedStatement stmt2 = conn.prepareStatement("update administratori set lozinka=? where korisnickoIme=?");
        ) {
            stmt1.setString(1, korisnickoIme);
            ResultSet rs = stmt1.executeQuery();
            if(rs.next()){
                //if(PasswordUtils.checkPassword(staraLozinka, rs.getString(2))){
                    novaLozinka = PasswordUtils.hashPassword(novaLozinka);
                    stmt2.setString(1, novaLozinka);
                    stmt2.setString(2, korisnickoIme);
                    stmt2.executeUpdate();
                    rs = stmt1.executeQuery();
                    if(rs.next()){
                    return new Administrator(
                        rs.getString(1),
                        rs.getString(2),
                        rs.getString(3),
                        rs.getString(4),
                        rs.getString(5)
                        );
                    }
                //}
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

}
