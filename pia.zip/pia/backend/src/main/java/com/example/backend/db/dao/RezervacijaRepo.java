package com.example.backend.db.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import com.example.backend.db.DB;
import com.example.backend.db.entities.Rezervacija;

public class RezervacijaRepo {
    
    public Rezervacija insertRezervacija(Rezervacija rezervacija){
        try (
            Connection conn = DB.source().getConnection();
            PreparedStatement stmt1 = conn.prepareStatement(
                "insert into rezervacije (" + 
                "idvikendice, korisnickoimevlasnika, korisnickoimeturiste," +
                "vremerezervacije, oddatuma, dodatuma, brojodraslih, brojdece," + 
                "cena, nazivvikendice, mesto, obradjena)"+
                "values (?,?,?,?,?,?,?,?,?,?,?,?)");
            PreparedStatement stmt2 = conn.prepareStatement("select * from rezervacije where idVikendice=? and korisnickoImeVlasnika=? and korisnickoImeTuriste=?");
        ) {
            stmt1.setInt(1, rezervacija.getIdVikendice());
            stmt1.setString(2, rezervacija.getKorisnickoImeVlasnika());
            stmt1.setString(3, rezervacija.getKorisnickoImeTuriste());
            stmt1.setTimestamp(4, Timestamp.valueOf(rezervacija.getVremeRezervacije()));
            stmt1.setDate(5, Date.valueOf(rezervacija.getOdDatuma()));
            stmt1.setDate(6, Date.valueOf(rezervacija.getDoDatuma()));
            stmt1.setInt(7, rezervacija.getBrojOdraslih());
            stmt1.setInt(8, rezervacija.getBrojDece());
            stmt1.setFloat(9, rezervacija.getCena());
            stmt1.setString(10, rezervacija.getNazivVikendice());
            stmt1.setString(11, rezervacija.getMesto());
            stmt1.setBoolean(12, false );

            stmt1.executeUpdate();

            stmt2.setInt(1, rezervacija.getIdVikendice());
            stmt2.setString(2, rezervacija.getKorisnickoImeVlasnika());
            stmt2.setString(3, rezervacija.getKorisnickoImeTuriste());
            ResultSet rs = stmt2.executeQuery();
            if(rs.next()){
                return new Rezervacija(
                    rs.getInt("idRezervacije"),
                    rs.getInt("idVikendice"),
                    rs.getString("korisnickoImeVlasnika"),
                    rs.getString("korisnickoImeTuriste"),
                    rs.getTimestamp("vremeRezervacije").toLocalDateTime(),
                    rs.getDate("odDatuma").toLocalDate(),
                    rs.getDate("doDatuma").toLocalDate(),
                    rs.getInt("brojOdraslih"),
                    rs.getInt("brojDece"),
                    rs.getFloat("cena"),
                    rs.getString("nazivVikendice"),
                    rs.getString("komentar"),
                    rs.getInt("ocena"),
                    rs.getString("mesto"),
                    rs.getBoolean("obradjena")
                );
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public boolean checkDatum(Date odDatuma, Date doDatuma){
        try (
            Connection conn = DB.source().getConnection();
            PreparedStatement stmt = conn.prepareStatement(
                "select * " +
                "from rezervacije " +
                "where " +
                "(odDatuma <= ? and doDatuma >= ? and doDatuma <= ?) or " + 
                "(odDatuma >= ? and odDatuma <= ? and doDatuma >= ?) or " + 
                "(odDatuma >= ? and odDatuma <= ? and doDatuma >= ? and doDatuma <= ?) or " +
                "(odDatuma <= ? and doDatuma >= ?)"
            );
        ) {
            stmt.setDate(1, odDatuma);
            stmt.setDate(2, odDatuma);
            stmt.setDate(3, doDatuma);

            stmt.setDate(4, odDatuma);
            stmt.setDate(5, doDatuma);
            stmt.setDate(6, doDatuma);

            stmt.setDate(7, odDatuma);
            stmt.setDate(8, doDatuma);
            stmt.setDate(9, odDatuma);
            stmt.setDate(10, doDatuma);

            stmt.setDate(11, odDatuma);
            stmt.setDate(12, doDatuma);

            ResultSet rs = stmt.executeQuery();

            if(rs.next()){
                return false;
            }
            else{
                return true;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    public List<Rezervacija> getArhiva(String korisnickoIme){
        try (
            Connection conn = DB.source().getConnection();
            PreparedStatement stmt = conn.prepareStatement("select * from rezervacije where korisnickoImeTuriste=? and doDatuma<? order by odDatuma desc");
        ) {
            stmt.setString(1, korisnickoIme);
            stmt.setDate(2, Date.valueOf(LocalDate.now()));
            ResultSet rs = stmt.executeQuery();
            Rezervacija rezervacija;
            List<Rezervacija> rezervacije = new ArrayList<>();
            while(rs.next()){
                rezervacija = new Rezervacija(
                    rs.getInt("idRezervacije"),
                    rs.getInt("idVikendice"),
                    rs.getString("korisnickoImeVlasnika"),
                    rs.getString("korisnickoImeTuriste"),
                    rs.getTimestamp("vremeRezervacije").toLocalDateTime(),
                    rs.getDate("odDatuma").toLocalDate(),
                    rs.getDate("doDatuma").toLocalDate(),
                    rs.getInt("brojOdraslih"),
                    rs.getInt("brojDece"),
                    rs.getFloat("cena"),
                    rs.getString("nazivVikendice"),
                    rs.getString("komentar"),
                    rs.getInt("ocena"),
                    rs.getString("mesto"),
                    rs.getBoolean("obradjena")
                );
                rezervacije.add(rezervacija);
            }
            return rezervacije;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public List<Rezervacija> getRezervacije(String korisnickoIme){
        try (
            Connection conn = DB.source().getConnection();
            PreparedStatement stmt = conn.prepareStatement("select * from rezervacije where korisnickoImeTuriste=? and ((odDatuma<=? and doDatuma>=?) or odDatuma>=?) order by odDatuma");
        ) {
            Date danas = Date.valueOf(LocalDate.now());
            stmt.setString(1, korisnickoIme);
            stmt.setDate(2, danas);
            stmt.setDate(3, danas);
            stmt.setDate(4, danas);
            ResultSet rs = stmt.executeQuery();
            Rezervacija rezervacija;
            List<Rezervacija> rezervacije = new ArrayList<>();
            while(rs.next()){
                rezervacija = new Rezervacija(
                    rs.getInt("idRezervacije"),
                    rs.getInt("idVikendice"),
                    rs.getString("korisnickoImeVlasnika"),
                    rs.getString("korisnickoImeTuriste"),
                    rs.getTimestamp("vremeRezervacije").toLocalDateTime(),
                    rs.getDate("odDatuma").toLocalDate(),
                    rs.getDate("doDatuma").toLocalDate(),
                    rs.getInt("brojOdraslih"),
                    rs.getInt("brojDece"),
                    rs.getFloat("cena"),
                    rs.getString("nazivVikendice"),
                    rs.getString("komentar"),
                    rs.getInt("ocena"),
                    rs.getString("mesto"),
                    rs.getBoolean("obradjena")
                );
                rezervacije.add(rezervacija);
            }
            return rezervacije;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public int updateKomentarOcena(int idRezervacije, String komentar, int ocena){
        try (
            Connection conn = DB.source().getConnection();
            PreparedStatement stmt = conn.prepareStatement("update rezervacije set komentar=?, ocena=?, vreme=? where idRezervacije=?");
        ) {
            stmt.setString(1, komentar);
            stmt.setInt(2, ocena);
            stmt.setTimestamp(3, Timestamp.valueOf(LocalDateTime.now()));
            stmt.setInt(4, idRezervacije);
            return stmt.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return 0;
    }

    public boolean deleteRezervacija(int idRezervacije){
        try (
            Connection conn = DB.source().getConnection();
            PreparedStatement stmt = conn.prepareStatement("delete from rezervacije where idRezervacije=?")
        ) {
            stmt.setInt(1, idRezervacije);
            int i = stmt.executeUpdate();
            if(i>0) return true;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    public List<Rezervacija> getNeobradjeneRezervacije(String korisnickoIme){
        try (
            Connection conn = DB.source().getConnection();
            PreparedStatement stmt = conn.prepareStatement("select * from rezervacije where korisnickoImeVlasnika=? and obradjena=0 order by odDatuma desc");
        ) {
            stmt.setString(1, korisnickoIme);
            ResultSet rs = stmt.executeQuery();
            Rezervacija rezervacija;
            List<Rezervacija> rezervacije = new ArrayList<>();
            while(rs.next()){
                rezervacija = new Rezervacija(
                    rs.getInt("idRezervacije"),
                    rs.getInt("idVikendice"),
                    rs.getString("korisnickoImeVlasnika"),
                    rs.getString("korisnickoImeTuriste"),
                    rs.getTimestamp("vremeRezervacije").toLocalDateTime(),
                    rs.getDate("odDatuma").toLocalDate(),
                    rs.getDate("doDatuma").toLocalDate(),
                    rs.getInt("brojOdraslih"),
                    rs.getInt("brojDece"),
                    rs.getFloat("cena"),
                    rs.getString("nazivVikendice"),
                    rs.getString("komentar"),
                    rs.getInt("ocena"),
                    rs.getString("mesto"),
                    rs.getBoolean("obradjena")
                );
                rezervacije.add(rezervacija);
            }
            return rezervacije;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public int prihvatiRezervaciju(int idRezervacije){
        try (
            Connection conn = DB.source().getConnection();
            PreparedStatement stmt1 = conn.prepareStatement("update rezervacije set obradjena=1 where idRezervacije=?");
            PreparedStatement stmt2 = conn.prepareStatement("insert into prihvacene(idRezervacije) values(?)")
        ) {
            stmt1.setInt(1, idRezervacije);
            stmt2.setInt(1, idRezervacije);
            int i = stmt1.executeUpdate();
            int k = stmt2.executeUpdate();
            return i+k;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return 0;
    } 

    public int odbijRezervaciju(int idRezervacije, String razlog){
        try (
            Connection conn = DB.source().getConnection();
            PreparedStatement stmt1 = conn.prepareStatement("update rezervacije set obradjena=1 where idRezervacije=?");
            PreparedStatement stmt2 = conn.prepareStatement("insert into odbijene(idRezervacije, razlog) values(?,?)");
        ) {
            stmt1.setInt(1, idRezervacije);
            stmt2.setInt(1, idRezervacije);
            stmt2.setString(2, razlog);
            return stmt1.executeUpdate() + stmt2.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return 0;
    }


}
