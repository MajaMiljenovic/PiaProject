package com.example.backend.controllers;

import java.io.IOException;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.example.backend.db.dao.AdminRepo;
import com.example.backend.db.dao.KorisnikRepo;
import com.example.backend.db.entities.Administrator;
import com.example.backend.db.entities.Korisnik;

@RestController
@RequestMapping({"/auth"})
@CrossOrigin(origins = "http://localhost:4200")
public class AuthController {
    
    @PostMapping("/login-korisnik")
    public Korisnik loginKorisnik(@RequestBody Korisnik korisnik) {
        return new KorisnikRepo().loginKorisnik(korisnik.getKorisnickoIme(), korisnik.getLozinka());
    }

    @PostMapping("/login-admin")
    public Administrator loginAdmin(@RequestBody Administrator administrator) {
        return new AdminRepo().loginAdministrator(administrator.getKorisnickoIme(), administrator.getLozinka());
    }
    
    @PostMapping("/register-korisnik")
    public Korisnik registerKorisnik(
            @RequestParam("korisnickoIme") String korisnickoIme,
            @RequestParam("lozinka") String lozinka,
            @RequestParam("ime") String ime,
            @RequestParam("prezime") String prezime,
            @RequestParam("pol") String pol,
            @RequestParam("adresa") String adresa,
            @RequestParam("telefon") String telefon,
            @RequestParam("mejl") String mejl,
            @RequestParam("kartica") String kartica,
            @RequestPart("slika") MultipartFile slika,
            @RequestParam("tip") String tip,
            @RequestParam("aktivan") String aktivan
    ) throws IOException {
        Korisnik korisnik = new Korisnik();
        korisnik.setKorisnickoIme(korisnickoIme);
        korisnik.setLozinka(lozinka);
        korisnik.setIme(ime);
        korisnik.setPrezime(prezime);
        korisnik.setPol(pol);
        korisnik.setAdresa(adresa);
        korisnik.setTelefon(telefon);
        korisnik.setMejl(mejl);
        korisnik.setKartica(kartica);
        korisnik.setTip(tip);
        korisnik.setSlika(slika.getBytes());
        korisnik.setAktivan(aktivan);

        return new KorisnikRepo().registerKorisnik(korisnik);
    }

    @PostMapping("/change-lozinka")
    public Korisnik changeLozinka(
        @RequestParam("korisnickoIme") String korisnickoIme,
        @RequestParam("staraLozinka") String staraLozinka,
        @RequestParam("novaLozinka") String novaLozinka
    ) throws IOException {
        return new KorisnikRepo().changeLozinka(korisnickoIme, staraLozinka, novaLozinka);
    }

    @PostMapping("/change-lozinka-admin")
    public Administrator changeLozinkaAdmin(
        @RequestParam("korisnickoIme") String korisnickoIme,
        @RequestParam("staraLozinka") String staraLozinka,
        @RequestParam("novaLozinka") String novaLozinka
    ) throws IOException {
        return new AdminRepo().changeLozinkaAdmin(korisnickoIme, staraLozinka, novaLozinka);
    }

}
