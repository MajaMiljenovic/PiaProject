package com.example.backend.db.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.example.backend.db.DB;
import com.example.backend.db.entities.Slika;
import com.example.backend.db.entities.Vikendica;

public class VikendicaRepo {


    public List<Vikendica> getAllVikendice(String select, String naziv, String mesto) {
        try (
            Connection conn = DB.source().getConnection();
            PreparedStatement stmtSortNazivAsc = conn.prepareStatement("select * from vikendice order by naziv asc");
            PreparedStatement stmtSortNazivDesc = conn.prepareStatement("select * from vikendice order by naziv desc");
            PreparedStatement stmtSortMestoAsc = conn.prepareStatement("select * from vikendice order by mesto asc");
            PreparedStatement stmtSortMestoDesc = conn.prepareStatement("select * from vikendice order by mesto desc");
            PreparedStatement stmtSearchNazivAsc = conn.prepareStatement("select * from vikendice where naziv=? or mesto=? order by naziv asc");
            PreparedStatement stmtSearchNazivDesc = conn.prepareStatement("select * from vikendice where naziv=? or mesto=? order by naziv desc");
            PreparedStatement stmtSearchMestoAsc = conn.prepareStatement("select * from vikendice where naziv=? or mesto=? order by mesto asc");
            PreparedStatement stmtSearchMestoDesc = conn.prepareStatement("select * from vikendice where naziv=? or mesto=? order by mesto desc");
        ) {
            ResultSet rs = null;
            if("".equals(naziv) && "".equals(mesto)){
                if("nazivasc".equals(select)) rs = stmtSortNazivAsc.executeQuery();
                if("nazivdesc".equals(select)) rs = stmtSortNazivDesc.executeQuery();
                if("mestoasc".equals(select)) rs = stmtSortMestoAsc.executeQuery();
                if("mestodesc".equals(select)) rs = stmtSortMestoDesc.executeQuery();
            }
            else{
                if("nazivasc".equals(select)){
                    stmtSearchNazivAsc.setString(1, naziv);
                    stmtSearchNazivAsc.setString(2, mesto);
                    rs = stmtSearchNazivAsc.executeQuery();
                }
                if("nazivdesc".equals(select)){
                    stmtSearchNazivDesc.setString(1, naziv);
                    stmtSearchNazivDesc.setString(2, mesto);
                    rs = stmtSearchNazivDesc.executeQuery();
                }
                if("mestoasc".equals(select)){
                    stmtSearchMestoAsc.setString(1, naziv);
                    stmtSearchMestoAsc.setString(2, mesto);
                    rs = stmtSearchMestoAsc.executeQuery();
                }
                if("mestodesc".equals(select)){
                    stmtSearchMestoDesc.setString(1, naziv);
                    stmtSearchMestoDesc.setString(2, mesto);
                    rs = stmtSearchMestoDesc.executeQuery();
                }
            } 
            List<Vikendica> vikendice = new ArrayList<>();
            Vikendica vikendica;
            while(rs.next()){
                vikendica = new Vikendica(
                    rs.getInt(1),
                    rs.getString(2),
                    rs.getString(3),
                    rs.getString(4),
                    rs.getString(5),
                    rs.getFloat(6),
                    rs.getFloat(7),
                    rs.getString(8),
                    rs.getDouble(9),
                    rs.getDouble(10),
                    rs.getFloat(11)
                );
                vikendice.add(vikendica);
            }
            return vikendice;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public Vikendica getVikendica(int idVikendice) {
        try(
            Connection conn = DB.source().getConnection();
            PreparedStatement stmt = conn.prepareStatement("select * from vikendice where idVikendice=?");
        ) {
            stmt.setInt(1, idVikendice);
            ResultSet rs = stmt.executeQuery();
            if(rs.next()){
                return new Vikendica(
                    rs.getInt(1),
                    rs.getString(2),
                    rs.getString(3),
                    rs.getString(4),
                    rs.getString(5),
                    rs.getFloat(6),
                    rs.getFloat(7),
                    rs.getString(8),
                    rs.getDouble(9),
                    rs.getDouble(10),
                    rs.getFloat(11)
                );
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public int obrisiVikendicu(int idVikendice){
        try (
            Connection conn = DB.source().getConnection();
            PreparedStatement stmt = conn.prepareStatement("delete from vikedice where idVikendice=?");
        ) {
            stmt.setInt(1, idVikendice);
            return stmt.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return 0;
    }
    
    public List<Slika> getAllSlike(int idVikendice){
        try (
            Connection conn = DB.source().getConnection();
            PreparedStatement stmt = conn.prepareStatement("select * from galerija where idVikendice=?");
        ) {
            stmt.setInt(1, idVikendice);
            ResultSet rs = stmt.executeQuery();
            Slika slika;
            List<Slika> slike = new ArrayList<>();
            while(rs.next()){
                slika = new Slika(
                    rs.getInt(1),
                    rs.getInt(2),
                    rs.getBytes(3)
                );
                slike.add(slika);
            }
            return slike;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public float updateOcena(int idVikendice){
        try (
            Connection conn = DB.source().getConnection();
            PreparedStatement stmt1 = conn.prepareStatement("select ocena from rezervacije where idVikendice=? and ocena is not null");
            PreparedStatement stmt2 = conn.prepareStatement("update vikendice set ocena=? where idVikendice=?");
        ) {
            stmt1.setInt(1, idVikendice);
            ResultSet rs = stmt1.executeQuery();
            int i = 0;
            int sum = 0;
            while(rs.next()){
                sum = sum + rs.getInt("ocena");
                i++;
            }
            float ocena = sum / i;
            stmt2.setFloat(1, ocena);
            stmt2.setInt(2, idVikendice);
            stmt2.executeUpdate();
            return ocena;
        } catch (Exception e) {
        }
        return 0;
    }

    public List<Vikendica> getMojeVikendice(String korisnickoIme) {
        try (
            Connection conn = DB.source().getConnection();
            PreparedStatement stmt = conn.prepareStatement("select * from vikendice where korisnickoImeVlasnika=? order by naziv asc");
        ) {
            stmt.setString(1, korisnickoIme);
            ResultSet rs = stmt.executeQuery();
            List<Vikendica> vikendice = new ArrayList<>();
            Vikendica vikendica;
            while(rs.next()){
                vikendica = new Vikendica(
                    rs.getInt(1),
                    rs.getString(2),
                    rs.getString(3),
                    rs.getString(4),
                    rs.getString(5),
                    rs.getFloat(6),
                    rs.getFloat(7),
                    rs.getString(8),
                    rs.getDouble(9),
                    rs.getDouble(10),
                    rs.getFloat(11)
                );
                vikendice.add(vikendica);
            }
            return vikendice;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public int updateNaziv(int idVikendice, String naziv) {
        try (
            Connection conn = DB.source().getConnection();
            PreparedStatement stmt = conn.prepareStatement("update vikendice set naziv=? where idVikendice=?");
        ) {
            stmt.setString(1, naziv);
            stmt.setInt(2, idVikendice);
            return stmt.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return 0;
    }

    public int updateMesto(int idVikendice, String mesto) {
        try (
            Connection conn = DB.source().getConnection();
            PreparedStatement stmt = conn.prepareStatement("update vikendice set v=? where idVikendice=?");
        ) {
            stmt.setString(1, mesto);
            stmt.setInt(2, idVikendice);
            return stmt.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return 0;
    }

    public int updateOpis(int idVikendice, String opis) {
        try (
            Connection conn = DB.source().getConnection();
            PreparedStatement stmt = conn.prepareStatement("update vikendice set opis=? where idVikendice=?");
        ) {
            stmt.setString(1, opis);
            stmt.setInt(2, idVikendice);
            return stmt.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return 0;
    }

    public int updateCenaLeto(int idVikendice, int cenaLeto) {
        try (
            Connection conn = DB.source().getConnection();
            PreparedStatement stmt = conn.prepareStatement("update vikendice set cenaLeto=? where idVikendice=?");
        ) {
            stmt.setInt(1, cenaLeto);
            stmt.setInt(2, idVikendice);
            return stmt.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return 0;
    }

    public int updateCenaZima(int idVikendice, int cenaZima) {
        try (
            Connection conn = DB.source().getConnection();
            PreparedStatement stmt = conn.prepareStatement("update vikendice set cenaZima=? where idVikendice=?");
        ) {
            stmt.setInt(1, cenaZima);
            stmt.setInt(2, idVikendice);
            return stmt.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return 0;
    }

    public int updateTelefon(int idVikendice, String telefon) {
        try (
            Connection conn = DB.source().getConnection();
            PreparedStatement stmt = conn.prepareStatement("update vikendice set telefon=? where idVikendice=?");
        ) {
            stmt.setString(1, telefon);
            stmt.setInt(2, idVikendice);
            return stmt.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return 0;
    }

    public int updateLat(int idVikendice, int lat) {
        try (
            Connection conn = DB.source().getConnection();
            PreparedStatement stmt = conn.prepareStatement("update vikendice set lat=? where idVikendice=?");
        ) {
            stmt.setInt(1, lat);
            stmt.setInt(2, idVikendice);
            return stmt.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return 0;
    }

    public int updateLng(int idVikendice, int lng) {
        try (
            Connection conn = DB.source().getConnection();
            PreparedStatement stmt = conn.prepareStatement("update vikendice set lng=? where idVikendice=?");
        ) {
            stmt.setInt(1, lng);
            stmt.setInt(2, idVikendice);
            return stmt.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return 0;
    }

    public List<Vikendica> getAllVikendiceAdmin() {
        try (
            Connection conn = DB.source().getConnection();
            PreparedStatement stmt = conn.prepareStatement("select * from vikendice order by naziv asc");
        ) {
            ResultSet rs = stmt.executeQuery();
            List<Vikendica> vikendice = new ArrayList<>();
            Vikendica vikendica;
            while(rs.next()){
                vikendica = new Vikendica(
                    rs.getInt(1),
                    rs.getString(2),
                    rs.getString(3),
                    rs.getString(4),
                    rs.getString(5),
                    rs.getFloat(6),
                    rs.getFloat(7),
                    rs.getString(8),
                    rs.getDouble(9),
                    rs.getDouble(10),
                    rs.getFloat(11)
                );
                vikendice.add(vikendica);
            }
            return vikendice;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public int insertVikendica(Vikendica vikendica) {
        try (
            Connection conn = DB.source().getConnection();
            PreparedStatement stmt = conn.prepareStatement("insert into vikendice(korisnickoImeVlasnika, naziv, mesto, opis, cenaLeto, cenaZima, telefon, lat, lng) values(?,?,?,?,?,?,?,?,?)", Statement.RETURN_GENERATED_KEYS);
        ) {
            stmt.setString(1, vikendica.getKorisnickoImeVlasnika());
            stmt.setString(2, vikendica.getNaziv());
            stmt.setString(3, vikendica.getMesto());
            stmt.setString(4, vikendica.getOpis());
            stmt.setFloat(5, vikendica.getCenaLeto());
            stmt.setFloat(6, vikendica.getCenaZima());
            stmt.setString(7, vikendica.getTelefon());
            stmt.setDouble(8, vikendica.getLat());
            stmt.setDouble(9, vikendica.getLng());
            stmt.executeUpdate();
            try (ResultSet generatedKeys = stmt.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    return generatedKeys.getInt(1);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return 0;
    }

    public int insertSlika(int idVikendice, byte[] slika) {
        try (
            Connection conn = DB.source().getConnection();
            PreparedStatement stmt = conn.prepareStatement("insert into galerija(idVikendice, slika) values(?,?)");
        ) {
            stmt.setInt(1, idVikendice);
            stmt.setBytes(2, slika);
            return stmt.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return 0;
    }

    /*public List<Integer> getLose(){
        try (
            Connection conn = DB.source().getConnection();
            PreparedStatement stmt = conn.prepareStatement("select idVikendice, ocena, vreme from vikendice order by vreme desc limit 3");
        ) {
            ResultSet rs = stmt.executeQuery();
            int idVikendice;
            List<Integer> vikendice = new ArrayList<>();
            while(rs.next()){
                idVikendice = rs.getInt(1);
                vikendice.add(idVikendice);
            }
            return vikendice; 
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }*/

    public int deleteSlika(Slika slika) {
        try (
            Connection conn = DB.source().getConnection();
            PreparedStatement stmt = conn.prepareStatement("delete from galerija where idSlike=?");
        ) {
            stmt.setInt(1, slika.getIdSlike());
            return stmt.executeUpdate(); 
        } catch (Exception e) {
            e.printStackTrace();
        }
        return 0;
    }

    

    

}
