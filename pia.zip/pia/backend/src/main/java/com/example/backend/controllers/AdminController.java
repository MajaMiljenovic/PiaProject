package com.example.backend.controllers;

import java.util.List;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.backend.db.dao.KorisnikRepo;
import com.example.backend.db.dao.VikendicaRepo;
import com.example.backend.db.entities.Korisnik;
import com.example.backend.db.entities.Vikendica;



@RestController
@RequestMapping("/admin")
@CrossOrigin(origins = "http://localhost:4200")
public class AdminController {


    @GetMapping("/zahtevi/prihvati/{korisnickoIme}")
    public int prihvatiZahtev(@PathVariable String korisnickoIme) {
        return new KorisnikRepo().prihvatiZahtev(korisnickoIme);
    }
    
    @GetMapping("/zahtevi/odbij/{korisnickoIme}")
    public int odbijZahtev(@PathVariable String korisnickoIme) {
        return new KorisnikRepo().odbijZahtev(korisnickoIme);
    }

    @GetMapping("/get-zahtevi")
    public List<Korisnik> getZahtevi() {
        return new KorisnikRepo().getZahtevi();
    }

    @GetMapping("/get-all-vikendice-admin")
    public List<Vikendica> getAllVikendice() {
        return new VikendicaRepo().getAllVikendiceAdmin();
    }
    
    @GetMapping("/get-all-turisti")
    public List<Korisnik> getAllTuristi() {
        return new KorisnikRepo().getAllTuristi();
    }

    @GetMapping("/get-all-vlasnici")
    public List<Korisnik> getAllVlasnici() {
        return new KorisnikRepo().getAllVlasnici();
    }  

    /*@GetMapping("/get-lose")
    public List<Integer> getLose() {
        return new VikendicaRepo().getLose();
    }*/
    
}