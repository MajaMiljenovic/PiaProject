package com.example.backend.db.entities;

public class KomentarOcenaDTO {

    private int idRezervacije;
    private String korisnickoIme;
    private String komentar;
    private int ocena;

    public KomentarOcenaDTO(int idRezervacije, String korisnickoIme, String komentar, int ocena) {
        this.idRezervacije = idRezervacije;
        this.komentar = komentar;
        this.ocena = ocena;
        this.korisnickoIme = korisnickoIme;
    }

    public int getIdRezervacije() {
        return idRezervacije;
    }

    public void setIdRezervacije(int idRezervacije) {
        this.idRezervacije = idRezervacije;
    }

    public String getKomentar() {
        return komentar;
    }

    public void setKomentar(String komentar) {
        this.komentar = komentar;
    }

    public int getOcena() {
        return ocena;
    }

    public void setOcena(int ocena) {
        this.ocena = ocena;
    }

    public String getKorisnickoIme() {
        return korisnickoIme;
    }

    public void setKorisnickoIme(String korisnickoIme) {
        this.korisnickoIme = korisnickoIme;
    }


}
