package com.example.backend.db.entities;


public class PodaciDTO {

    private int vikendiceCnt;
    private int vlasniciCnt;
    private int turistiCnt;
    private int rezervacije24Cnt;
    private int rezervacije7Cnt;
    private int rezervacije30Cnt;

    public PodaciDTO(
        int vikendiceCnt, 
        int vlasniciCnt, 
        int turistiCnt, 
        int rezervacije24Cnt, 
        int rezervacije7Cnt, 
        int rezervacije30Cnt
    ) {
        this.rezervacije24Cnt = rezervacije24Cnt;
        this.rezervacije30Cnt = rezervacije30Cnt;
        this.rezervacije7Cnt = rezervacije7Cnt;
        this.turistiCnt = turistiCnt;
        this.vikendiceCnt = vikendiceCnt;
        this.vlasniciCnt = vlasniciCnt;
    }

    public int getVikendiceCnt() {
        return vikendiceCnt;
    }

    public void setVikendiceCnt(int vikendiceCnt) {
        this.vikendiceCnt = vikendiceCnt;
    }

    public int getVlasniciCnt() {
        return vlasniciCnt;
    }

    public void setVlasniciCnt(int vlasniciCnt) {
        this.vlasniciCnt = vlasniciCnt;
    }

    public int getTuristiCnt() {
        return turistiCnt;
    }

    public void setTuristiCnt(int turistiCnt) {
        this.turistiCnt = turistiCnt;
    }

    public int getRezervacije24Cnt() {
        return rezervacije24Cnt;
    }

    public void setRezervacije24Cnt(int rezervacije24Cnt) {
        this.rezervacije24Cnt = rezervacije24Cnt;
    }

    public int getRezervacije7Cnt() {
        return rezervacije7Cnt;
    }

    public void setRezervacije7Cnt(int rezervacije7Cnt) {
        this.rezervacije7Cnt = rezervacije7Cnt;
    }

    public int getRezervacije30Cnt() {
        return rezervacije30Cnt;
    }

    public void setRezervacije30Cnt(int rezervacije30Cnt) {
        this.rezervacije30Cnt = rezervacije30Cnt;
    }




}
