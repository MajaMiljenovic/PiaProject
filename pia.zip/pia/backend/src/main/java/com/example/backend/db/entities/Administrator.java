package com.example.backend.db.entities;

public class Administrator {
    
    private String korisnickoIme;
    private String lozinka;
    private String ime;
    private String prezime;
    private String mejl;

    public Administrator(String korisnickoIme, String lozinka, String ime, String prezime, String mejl) {
        this.ime = ime;
        this.korisnickoIme = korisnickoIme;
        this.lozinka = lozinka;
        this.mejl = mejl;
        this.prezime = prezime;
    }

    public String getKorisnickoIme() {
        return korisnickoIme;
    }

    public void setKorisnickoIme(String korisnickoIme) {
        this.korisnickoIme = korisnickoIme;
    }

    public String getLozinka() {
        return lozinka;
    }

    public void setLozinka(String lozinka) {
        this.lozinka = lozinka;
    }

    public String getIme() {
        return ime;
    }

    public void setIme(String ime) {
        this.ime = ime;
    }

    public String getPrezime() {
        return prezime;
    }

    public void setPrezime(String prezime) {
        this.prezime = prezime;
    }

    public String getMejl() {
        return mejl;
    }

    public void setMejl(String mejl) {
        this.mejl = mejl;
    }

}
