package com.example.backend.controllers;

import java.io.IOException;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;

import com.example.backend.db.dao.KorisnikRepo;
import com.example.backend.db.entities.Korisnik;


@RestController
@RequestMapping("/profil")
@CrossOrigin(origins = "http://localhost:4200")
public class ProfilController {
    
    @PostMapping("/update-ime")
    public Korisnik updateIme(@RequestParam String korisnickoIme, @RequestParam String ime) {    
        return new KorisnikRepo().updateIme(korisnickoIme, ime);
    }

    @PostMapping("/update-prezime")
    public Korisnik updatePrezime(@RequestParam String korisnickoIme, @RequestParam String prezime) {    
        return new KorisnikRepo().updatePrezime(korisnickoIme, prezime);
    }

    @PostMapping("/update-adresa")
    public Korisnik updateAdresa(@RequestParam String korisnickoIme, @RequestParam String adresa) {    
        return new KorisnikRepo().updateAdresa(korisnickoIme, adresa);
    }

    @PostMapping("/update-mejl")
    public Korisnik updateMejl(@RequestParam String korisnickoIme, @RequestParam String mejl) {    
        return new KorisnikRepo().updateMejl(korisnickoIme, mejl);
    }

    @PostMapping("/update-telefon")
    public Korisnik updateTelefon(@RequestParam String korisnickoIme, @RequestParam String telefon) {    
        return new KorisnikRepo().updateTelefon(korisnickoIme, telefon);
    }

    @PostMapping("/update-kartica")
    public Korisnik updateKartica(@RequestParam String korisnickoIme, @RequestParam String kartica) {    
        return new KorisnikRepo().updateKartica(korisnickoIme, kartica);
    }

    @PostMapping("/update-slika")
    public Korisnik updateSlika(@RequestParam String korisnickoIme, @RequestPart("slika") MultipartFile slika) throws IOException {    
        return new KorisnikRepo().updateSlika(korisnickoIme, slika.getBytes());
    }
    

}
