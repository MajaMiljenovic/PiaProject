package com.example.backend.db.entities;

import java.time.LocalDate;
import java.time.LocalDateTime;

public class Rezervacija {

    private int idRezervacije;
    private int idVikendice;
    private String korisnickoImeVlasnika;
    private String korisnickoImeTuriste;
    private LocalDateTime vremeRezervacije;
    private LocalDate odDatuma;
    private LocalDate doDatuma;
    private int brojOdraslih;
    private int  brojDece;
    private float cena;
    private String nazivVikendice;
    private String komentar;
    private int ocena;
    private String mesto;
    private Boolean obradjena;

    public Rezervacija(
        int idRezervacije,
        int idVikendice,
        String korisnickoImeVlasnika,
        String korisnickoImeTuriste,
        LocalDateTime vremeRezervacije,
        LocalDate odDatuma,
        LocalDate doDatuma,
        int brojOdraslih,
        int  brojDece,
        float cena,
        String nazivVikendice,
        String komentar,
        int ocena,
        String mesto,
        Boolean obradjena
    ) {
        this.idRezervacije = idRezervacije;
        this.brojDece = brojDece;
        this.brojOdraslih = brojOdraslih;
        this.cena = cena;
        this.doDatuma = doDatuma;
        this.idVikendice = idVikendice;
        this.korisnickoImeTuriste = korisnickoImeTuriste;
        this.korisnickoImeVlasnika = korisnickoImeVlasnika;
        this.odDatuma = odDatuma;
        this.vremeRezervacije = vremeRezervacije;
        this.nazivVikendice = nazivVikendice;
        this.ocena = ocena;
        this.komentar = komentar;
        this.mesto = mesto;
        this.obradjena = obradjena;
    }

    

    public int getIdVikendice() {
        return idVikendice;
    }

    public void setIdVikendice(int idVikendice) {
        this.idVikendice = idVikendice;
    }

    public String getKorisnickoImeVlasnika() {
        return korisnickoImeVlasnika;
    }

    public void setKorisnickoImeVlasnika(String korisnickoImeVlasnika) {
        this.korisnickoImeVlasnika = korisnickoImeVlasnika;
    }

    public String getKorisnickoImeTuriste() {
        return korisnickoImeTuriste;
    }

    public void setKorisnickoImeTuriste(String korisnickoImeTuriste) {
        this.korisnickoImeTuriste = korisnickoImeTuriste;
    }

    public LocalDateTime getVremeRezervacije() {
        return vremeRezervacije;
    }

    public void setVremeRezervacije(LocalDateTime vremeRezervacije) {
        this.vremeRezervacije = vremeRezervacije;
    }

    public LocalDate getOdDatuma() {
        return odDatuma;
    }

    public void setOdDatuma(LocalDate odDatuma) {
        this.odDatuma = odDatuma;
    }

    public LocalDate getDoDatuma() {
        return doDatuma;
    }

    public void setDoDatuma(LocalDate doDatuma) {
        this.doDatuma = doDatuma;
    }

    public int getBrojOdraslih() {
        return brojOdraslih;
    }

    public void setBrojOdraslih(int brojOdraslih) {
        this.brojOdraslih = brojOdraslih;
    }

    public int getBrojDece() {
        return brojDece;
    }

    public void setBrojDece(int brojDece) {
        this.brojDece = brojDece;
    }

    public float getCena() {
        return cena;
    }

    public void setCena(float cena) {
        this.cena = cena;
    }

    public int getIdRezervacije() {
        return idRezervacije;
    }

    public void setIdRezervacije(int idRezervacije) {
        this.idRezervacije = idRezervacije;
    }

    public String getNazivVikendice() {
        return nazivVikendice;
    }

    public void setNazivVikendice(String nazivVikendice) {
        this.nazivVikendice = nazivVikendice;
    }

    public String getKomentar() {
        return komentar;
    }

    public void setKomentar(String komentar) {
        this.komentar = komentar;
    }

    public int getOcena() {
        return ocena;
    }

    public void setOcena(int ocena) {
        this.ocena = ocena;
    }

    public String getMesto() {
        return mesto;
    }

    public void setMesto(String mesto) {
        this.mesto = mesto;
    }

    public Boolean getObradjena() {
        return obradjena;
    }

    public void setObradjena(Boolean obradjena) {
        this.obradjena = obradjena;
    }


    
}
