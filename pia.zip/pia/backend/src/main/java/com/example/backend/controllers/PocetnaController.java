package com.example.backend.controllers;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.backend.db.dao.RandomRepo;
import com.example.backend.db.entities.PodaciDTO;



@RestController
@RequestMapping("/podaci")
@CrossOrigin(origins = "http://localhost:4200")
public class PocetnaController {

    @GetMapping()
    public PodaciDTO getAllPodacilogin() {
        return new RandomRepo().getAllPodaci();
    }
    
}
