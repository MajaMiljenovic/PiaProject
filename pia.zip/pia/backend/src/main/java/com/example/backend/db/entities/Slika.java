package com.example.backend.db.entities;

public class Slika {

    private int idSlike;
    private int idVikendice;
    private byte[] slika;

    public Slika(int idSlike, int idVikendice, byte[] slika) {
        this.idSlike = idSlike;
        this.idVikendice = idVikendice;
        this.slika = slika;
    }

    public int getIdSlike() {
        return idSlike;
    }

    public void setIdSlike(int idSlike) {
        this.idSlike = idSlike;
    }

    public int getIdVikendice() {
        return idVikendice;
    }

    public void setIdVikendice(int idVikendice) {
        this.idVikendice = idVikendice;
    }

    public byte[] getSlika() {
        return slika;
    }

    public void setSlika(byte[] slika) {
        this.slika = slika;
    }


}
