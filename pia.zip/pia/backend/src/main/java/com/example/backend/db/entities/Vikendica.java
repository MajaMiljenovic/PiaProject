package com.example.backend.db.entities;

public class Vikendica {

    private int idVikendice;
    private String korisnickoImeVlasnika;
    private String naziv;
    private String mesto;
    private String opis;
    private float cenaLeto;
    private float cenaZima;
    private String telefon;
    private double lat;
    private double lng; 
    private float ocena;

    public Vikendica(
        int idVikendice,
        String korisnickoImeVlasnika,
        String naziv,
        String mesto,
        String opis,
        float  cenaLeto,
        float cenaZima,
        String telefon,
        double lat,
        double lng,
        float ocena
    ) {
        this.cenaLeto = cenaLeto;
        this.cenaZima = cenaZima;
        this.idVikendice = idVikendice;
        this.lat = lat;
        this.lng = lng;
        this.korisnickoImeVlasnika = korisnickoImeVlasnika;
        this.mesto = mesto;
        this.naziv = naziv;
        this.opis = opis;
        this.telefon = telefon;
        this.ocena = ocena;
    }

    public int getIdVikendice() {
        return idVikendice;
    }

    public void setIdVikendice(int idVikendice) {
        this.idVikendice = idVikendice;
    }

    public String getKorisnickoImeVlasnika() {
        return korisnickoImeVlasnika;
    }

    public void setKorisnickoImeVlasnika(String korisnickoImeVlasnika) {
        this.korisnickoImeVlasnika = korisnickoImeVlasnika;
    }

    public String getNaziv() {
        return naziv;
    }

    public void setNaziv(String naziv) {
        this.naziv = naziv;
    }

    public String getMesto() {
        return mesto;
    }

    public void setMesto(String mesto) {
        this.mesto = mesto;
    }

    public String getOpis() {
        return opis;
    }

    public void setOpis(String opis) {
        this.opis = opis;
    }

    public String getTelefon() {
        return telefon;
    }

    public void setTelefon(String telefon) {
        this.telefon = telefon;
    }

    public double getLat() {
        return lat;
    }

    public void setLat(double lat) {
        this.lat = lat;
    }

    public double getLng() {
        return lng;
    }

    public void setLng(double lng) {
        this.lng = lng;
    }

    public float getOcena() {
        return ocena;
    }

    public void setOcena(float ocena) {
        this.ocena = ocena;
    }

    public float getCenaLeto() {
        return cenaLeto;
    }

    public void setCenaLeto(float cenaLeto) {
        this.cenaLeto = cenaLeto;
    }

    public float getCenaZima() {
        return cenaZima;
    }

    public void setCenaZima(float cenaZima) {
        this.cenaZima = cenaZima;
    }




}
