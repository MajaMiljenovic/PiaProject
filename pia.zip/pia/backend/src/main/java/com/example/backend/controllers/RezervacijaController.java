package com.example.backend.controllers;

import java.sql.Date;
import java.util.List;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.backend.db.dao.RezervacijaRepo;
import com.example.backend.db.entities.KomentarOcenaDTO;
import com.example.backend.db.entities.Rezervacija;


@RestController
@RequestMapping("/rezervacija")
@CrossOrigin(origins = "http://localhost:4200")
public class RezervacijaController {
    
    @PostMapping()
    public Rezervacija insertRezervacija(@RequestBody Rezervacija rezervacija) {
        return new RezervacijaRepo().insertRezervacija(rezervacija);
    }

    @GetMapping("/{odDatuma}/{doDatuma}")
    public boolean checkDatum(@PathVariable Date odDatuma, @PathVariable Date doDatuma) {
        return new RezervacijaRepo().checkDatum(odDatuma, doDatuma);
    }

    @GetMapping("/get-arhiva")
    public List<Rezervacija> getArhiva(@RequestParam String korisnickoIme){
        return new RezervacijaRepo().getArhiva(korisnickoIme);
    }

    @GetMapping("/get-rezervacije")
    public List<Rezervacija> getRezervacije(@RequestParam String korisnickoIme){
        return new RezervacijaRepo().getRezervacije(korisnickoIme);
    }

    @PostMapping("/update-komentar-ocena")
    public int updateKomentarOcena(@RequestBody KomentarOcenaDTO body) {
        return new RezervacijaRepo().updateKomentarOcena(body.getIdRezervacije(), body.getKomentar(), body.getOcena());
    }
    
    @GetMapping("/delete-rezervacija/{idRezervacije}")
    public boolean deleteRezervacija(@PathVariable int idRezervacije){
        return new RezervacijaRepo().deleteRezervacija(idRezervacije);
    }

    @GetMapping("/get-neobradjene-rezervacije")
    public List<Rezervacija> getNeobradjeneRezervacije(@RequestParam String korisnickoIme){
        return new RezervacijaRepo().getNeobradjeneRezervacije(korisnickoIme);
    }

    @PostMapping("/prihvati-rezervaciju")
    public int prihvatiRezervaciju(@RequestBody int idRezervacije) {
        return new RezervacijaRepo().prihvatiRezervaciju(idRezervacije);
    }

    @PostMapping("/odbij-rezervaciju")
    public int odbijRezervaciju(@RequestParam int idRezervacije, @RequestParam String razlog){
        return new RezervacijaRepo().odbijRezervaciju(idRezervacije, razlog);
    }

    

}
