package com.example.backend.db.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.example.backend.db.DB;
import com.example.backend.db.entities.Korisnik;
import com.example.backend.db.entities.PasswordUtils;

public class KorisnikRepo {

    public Korisnik loginKorisnik(String korisnickoIme, String lozinka) {
        try(
            Connection conn = DB.source().getConnection();
            PreparedStatement stmt = conn.prepareStatement("select * from korisnici where korisnickoIme=?");
        ) {
            stmt.setString(1, korisnickoIme);
            ResultSet rs = stmt.executeQuery();
            if(rs.next()){
                if(PasswordUtils.checkPassword(lozinka, rs.getString(2))){
                    return new Korisnik(
                    rs.getString(1),
                    rs.getString(2),
                    rs.getString(3),
                    rs.getString(4),
                    rs.getString(5),
                    rs.getString(6),
                    rs.getString(7),
                    rs.getString(8),
                    rs.getBytes(9),
                    rs.getString(10),
                    rs.getString(11),
                    rs.getString(12)
                    );
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }


    public Korisnik registerKorisnik(Korisnik korisnik) {
        try(
            Connection conn = DB.source().getConnection();
            PreparedStatement stmt = conn.prepareStatement("insert into korisnici values(?,?,?,?,?,?,?,?,?,?,?,?)");
        ) {
            
            korisnik.setLozinka(PasswordUtils.hashPassword(korisnik.getLozinka()));
            stmt.setString(1, korisnik.getKorisnickoIme());
            stmt.setString(2, korisnik.getLozinka());
            stmt.setString(3, korisnik.getIme());
            stmt.setString(4, korisnik.getPrezime());
            stmt.setString(5, korisnik.getPol());
            stmt.setString(6, korisnik.getAdresa());
            stmt.setString(7, korisnik.getTelefon());
            stmt.setString(8, korisnik.getMejl());
            stmt.setBytes(9, korisnik.getSlika());
            stmt.setString(10, korisnik.getKartica());
            stmt.setString(11, korisnik.getTip());
            stmt.setString(12, korisnik.getAktivan());
            stmt.executeUpdate();
            return new Korisnik(korisnik);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    
    public int prihvatiZahtev(String korisnickoIme) {
        try (
            Connection conn = DB.source().getConnection();
            PreparedStatement stmt = conn.prepareStatement("update korisnici set aktivan='da' where korisnickoIme=?");
        ) {
            stmt.setString(1, korisnickoIme);
            return stmt.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return 0;
    }


    public int odbijZahtev(String korisnickoIme) {
        try (
            Connection conn = DB.source().getConnection();
            PreparedStatement stmt = conn.prepareStatement("update korisnici set aktivan='od' where korisnickoIme=?");
        ) {
            stmt.setString(1, korisnickoIme);
            return stmt.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return 0;
    }

    public Korisnik changeLozinka(String korisnickoIme, String staraLozinka, String novaLozinka) {
        try (
            Connection conn = DB.source().getConnection();
            PreparedStatement stmt1 = conn.prepareStatement("select * from korisnici where korisnickoIme=?");
            PreparedStatement stmt2 = conn.prepareStatement("update korisnici set lozinka=? where korisnickoIme=?");
        ) {
            stmt1.setString(1, korisnickoIme);
            ResultSet rs = stmt1.executeQuery();
            if(rs.next()){
                if(PasswordUtils.checkPassword(staraLozinka, rs.getString(2))){
                    novaLozinka = PasswordUtils.hashPassword(novaLozinka);
                    stmt2.setString(1, novaLozinka);
                    stmt2.setString(2, korisnickoIme);
                    stmt2.executeUpdate();
                    rs = stmt1.executeQuery();
                    if(rs.next()){
                        return new Korisnik(
                            rs.getString(1), rs.getString(2), rs.getString(3),
                            rs.getString(4), rs.getString(5), rs.getString(6),
                            rs.getString(7), rs.getString(8), rs.getBytes(9),
                            rs.getString(10), rs.getString(11), rs.getString(12)
                        );
                    }
            
                }
            }   
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public Korisnik updateIme(String korisnickoIme, String ime) {
        try (
            Connection conn = DB.source().getConnection();
            PreparedStatement stmt = conn.prepareStatement("update korisnici set ime=? where korisnickoIme=?");
            PreparedStatement stmtSelect = conn.prepareStatement("select * from korisnici where korisnickoIme=?");
        ) {
            stmt.setString(1, ime);
            stmt.setString(2, korisnickoIme);
            int rows = stmt.executeUpdate();
            if (rows > 0) {
                stmtSelect.setString(1, korisnickoIme);
                ResultSet rs = stmtSelect.executeQuery();
                if (rs.next()) {
                    return new Korisnik(
                        rs.getString(1), rs.getString(2), rs.getString(3),
                        rs.getString(4), rs.getString(5), rs.getString(6),
                        rs.getString(7), rs.getString(8), rs.getBytes(9),
                        rs.getString(10), rs.getString(11), rs.getString(12)
                    );
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }


    public Korisnik updatePrezime(String korisnickoIme, String prezime) {
    try (
        Connection conn = DB.source().getConnection();
        PreparedStatement stmt = conn.prepareStatement("select korisnici set prezime=? where korisnickoIme=?");
        PreparedStatement stmtSelect = conn.prepareStatement("select * from korisnici where korisnickoIme=?");
    ) {
        stmt.setString(1, prezime);
        stmt.setString(2, korisnickoIme);
        int rows = stmt.executeUpdate();

        if (rows > 0) {
            stmtSelect.setString(1, korisnickoIme);
            ResultSet rs = stmtSelect.executeQuery();
            if (rs.next()) {
                return new Korisnik(
                    rs.getString(1), rs.getString(2), rs.getString(3),
                    rs.getString(4), rs.getString(5), rs.getString(6),
                    rs.getString(7), rs.getString(8), rs.getBytes(9),
                    rs.getString(10), rs.getString(11), rs.getString(12)
                );
            }
        }
    } catch (Exception e) {
        e.printStackTrace();
    }
        return null;
    }

    public Korisnik updateAdresa(String korisnickoIme, String adresa) {
    try (
        Connection conn = DB.source().getConnection();
        PreparedStatement stmt = conn.prepareStatement("update korisnici set adresa=? where korisnickoIme=?");
        PreparedStatement stmtSelect = conn.prepareStatement("select * from korisnici where korisnickoIme=?");
    ) {
        stmt.setString(1, adresa);
        stmt.setString(2, korisnickoIme);
        int rows = stmt.executeUpdate();

        if (rows > 0) {
            stmtSelect.setString(1, korisnickoIme);
            ResultSet rs = stmtSelect.executeQuery();
            if (rs.next()) {
                return new Korisnik(
                    rs.getString(1), rs.getString(2), rs.getString(3),
                    rs.getString(4), rs.getString(5), rs.getString(6),
                    rs.getString(7), rs.getString(8), rs.getBytes(9),
                    rs.getString(10), rs.getString(11), rs.getString(12)
                );
            }
        }
    } catch (Exception e) {
        e.printStackTrace();
    }
        return null;
    }

    public Korisnik updateMejl(String korisnickoIme, String mejl) {
        try (
            Connection conn = DB.source().getConnection();
            PreparedStatement stmt = conn.prepareStatement("update korisnici set mejl=? where korisnickoIme=?");
            PreparedStatement stmtSelect = conn.prepareStatement("select * form korisnici where korisnickoIme=?");
        ) {
            stmt.setString(1, mejl);
            stmt.setString(2, korisnickoIme);
            int rows = stmt.executeUpdate();

            if (rows > 0) {
                stmtSelect.setString(1, korisnickoIme);
                ResultSet rs = stmtSelect.executeQuery();
                if (rs.next()) {
                    return new Korisnik(
                        rs.getString(1), rs.getString(2), rs.getString(3),
                        rs.getString(4), rs.getString(5), rs.getString(6),
                        rs.getString(7), rs.getString(8), rs.getBytes(9),
                        rs.getString(10), rs.getString(11), rs.getString(12)
                    );
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }


    public Korisnik updateTelefon(String korisnickoIme, String telefon) {
    try (
        Connection conn = DB.source().getConnection();
        PreparedStatement stmt = conn.prepareStatement("update korisnici set telefon=? where korisnickoIme=?");
        PreparedStatement stmtSelect = conn.prepareStatement("select * from korisnici where korisnickoIme=?");
    ) {
        stmt.setString(1, telefon);
        stmt.setString(2, korisnickoIme);
        int rows = stmt.executeUpdate();

        if (rows > 0) {
            stmtSelect.setString(1, korisnickoIme);
            ResultSet rs = stmtSelect.executeQuery();
            if (rs.next()) {
                return new Korisnik(
                    rs.getString(1), rs.getString(2), rs.getString(3),
                    rs.getString(4), rs.getString(5), rs.getString(6),
                    rs.getString(7), rs.getString(8), rs.getBytes(9),
                    rs.getString(10), rs.getString(11), rs.getString(12)
                );
            }
        }
    } catch (Exception e) {
        e.printStackTrace();
    }
        return null;
    }


    public Korisnik updateKartica(String korisnickoIme, String kartica) {
    try (
        Connection conn = DB.source().getConnection();
        PreparedStatement stmt = conn.prepareStatement("update korisnici set kartica=? where korisnickoIme=?");
        PreparedStatement stmtSelect = conn.prepareStatement("select * from korisnici where korisnickoIme=?");
    ) {
        stmt.setString(1, kartica);
        stmt.setString(2, korisnickoIme);
        int rows = stmt.executeUpdate();

        if (rows > 0) {
            stmtSelect.setString(1, korisnickoIme);
            ResultSet rs = stmtSelect.executeQuery();
            if (rs.next()) {
                return new Korisnik(
                    rs.getString(1), rs.getString(2), rs.getString(3),
                    rs.getString(4), rs.getString(5), rs.getString(6),
                    rs.getString(7), rs.getString(8), rs.getBytes(9),
                    rs.getString(10), rs.getString(11), rs.getString(12)
                );
            }
        }
    } catch (Exception e) {
        e.printStackTrace();
    }
        return null;
    }


    public Korisnik updateSlika(String korisnickoIme, byte[] slika) {
    try (
        Connection conn = DB.source().getConnection();
        PreparedStatement stmt = conn.prepareStatement("update korisnici set slika=? where korisnickoIme=?");
        PreparedStatement stmtSelect = conn.prepareStatement("select * from korisnici where korisnickoIme=?");
    ) {
        stmt.setBytes(1, slika);
        stmt.setString(2, korisnickoIme);
        int rows = stmt.executeUpdate();

        if (rows > 0) {
            stmtSelect.setString(1, korisnickoIme);
            ResultSet rs = stmtSelect.executeQuery();
            if (rs.next()) {
                return new Korisnik(
                    rs.getString(1), rs.getString(2), rs.getString(3),
                    rs.getString(4), rs.getString(5), rs.getString(6),
                    rs.getString(7), rs.getString(8), rs.getBytes(9),
                    rs.getString(10), rs.getString(11), rs.getString(12)
                );
            }
        }
    } catch (Exception e) {
        e.printStackTrace();
    }
        return null;
    }

    public List<Korisnik> getZahtevi() {
        try (
            Connection conn = DB.source().getConnection();
            PreparedStatement stmt = conn.prepareStatement("select * from korisnici where aktivan='ne'");
        ) {
            ResultSet rs = stmt.executeQuery();
            Korisnik korisnik;
            List<Korisnik> korisnici = new ArrayList<>();
            while(rs.next()){
                korisnik = new Korisnik(
                    rs.getString(1),
                    rs.getString(2),
                    rs.getString(3),
                    rs.getString(4),
                    rs.getString(5),
                    rs.getString(6),
                    rs.getString(7),
                    rs.getString(8),
                    rs.getBytes(9),
                    rs.getString(10),
                    rs.getString(11),
                    rs.getString(12)
                );
                korisnici.add(korisnik);
            }
            return korisnici;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public List<Korisnik> getAllTuristi() {
        try (
            Connection conn = DB.source().getConnection();
            PreparedStatement stmt = conn.prepareStatement("select * from korisnici where aktivan='da' and tip='turista' order by korisnickoIme");
        ) {
            ResultSet rs = stmt.executeQuery();
            Korisnik korisnik;
            List<Korisnik> korisnici = new ArrayList<>();
            while(rs.next()){
                korisnik = new Korisnik(
                    rs.getString(1),
                    rs.getString(2),
                    rs.getString(3),
                    rs.getString(4),
                    rs.getString(5),
                    rs.getString(6),
                    rs.getString(7),
                    rs.getString(8),
                    rs.getBytes(9),
                    rs.getString(10),
                    rs.getString(11),
                    rs.getString(12)
                );
                korisnici.add(korisnik);
            }
            return korisnici;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public List<Korisnik> getAllVlasnici() {
        try (
            Connection conn = DB.source().getConnection();
            PreparedStatement stmt = conn.prepareStatement("select * from korisnici where aktivan='da' and tip ='vlasnik' order by korisnickoIme");
        ) {
            ResultSet rs = stmt.executeQuery();
            Korisnik korisnik;
            List<Korisnik> korisnici = new ArrayList<>();
            while(rs.next()){
                korisnik = new Korisnik(
                    rs.getString(1),
                    rs.getString(2),
                    rs.getString(3),
                    rs.getString(4),
                    rs.getString(5),
                    rs.getString(6),
                    rs.getString(7),
                    rs.getString(8),
                    rs.getBytes(9),
                    rs.getString(10),
                    rs.getString(11),
                    rs.getString(12)
                );
                korisnici.add(korisnik);
            }
            return korisnici;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

}
