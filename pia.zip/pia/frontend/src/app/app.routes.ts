import { Routes } from '@angular/router';

import { LoginComponent } from './components/login/login.component';
import { RegisterComponent } from './components/register/register.component';
import { VikendiceTuristaComponent } from './components/vikendiceTurista/vikendice.component';
import { RezervacijeTuristaComponent } from './components/rezervacijeTurista/rezervacije.component';
import { ProfilComponent } from './components/profil/profil.component';
import { TuristaComponent } from './components/turista/turista.component';
import { VlasnikComponent } from './components/vlasnik/vlasnik.component';
import { LozinkaComponent } from './components/lozinka/lozinka.component';
import { VikendicaComponent } from './components/vikendicaTurista/vikendica.component';
import { RezervacijaComponent } from './components/rezervacija/rezervacija.component';
import { RezervacijeVlasnikComponent } from './components/rezervacijeVlasnik/rezervacije.component';
import { VikendiceVlasnikComponent } from './components/vikendiceVlasnik/vikendice-vlasnik.component';
import { AdminComponent } from './components/admin/admin.component';
import { LoginAdminComponent } from './components/login-admin/login-admin.component';
import { OperacijeComponent } from './components/operacije/operacije.component';
import { VikendicaVlasnikComponent } from './components/vikendicaVlasnik/vikendica-vlasnik.component';

export const routes: Routes = [

    { path: '', redirectTo: "/pocetna/login", pathMatch: "full" },
    { path: "pocetna/login", component: LoginComponent },
    { path: "pocetna/register", component: RegisterComponent },
    { path: "pocetna/lozinka", component: LozinkaComponent},
    { path: "pocetna/login/admin", component: LoginAdminComponent},

    { path: "turista", redirectTo: "/turista/profil", pathMatch: "full" },
    { path: 'turista', component: TuristaComponent,
        children: [
            { path: 'profil', component: ProfilComponent },
            { path: 'vikendice', component: VikendiceTuristaComponent },
            { path: 'vikendice/:idVikendice/:naziv', component: VikendicaComponent},
            { path: 'vikendice/:idVikendice/:naziv/rezervacija', component: RezervacijaComponent},
            { path: 'rezervacije', component: RezervacijeTuristaComponent },
        ]
    },
    
    { path: "vlasnik", redirectTo: "/vlasnik/profil", pathMatch: "full" },
    { path: 'vlasnik', component: VlasnikComponent,
        children: [
            { path: 'profil', component: ProfilComponent },
            { path: 'rezervacije', component: RezervacijeVlasnikComponent },
            { path: 'vikendice', component: VikendiceVlasnikComponent},
            { path: 'vikendice/:idVikendice/:naziv', component: VikendicaVlasnikComponent},
            { path: 'statistika', component: ProfilComponent}
        ]
    },

    { path: "admin", redirectTo: "/admin/operacije", pathMatch: "full" },
    { path: 'admin', component: AdminComponent,
        children: [
            { path: 'operacije', component: OperacijeComponent },
            { path: 'korisnik', component: ProfilComponent },
        ]
    },
        
    

];
