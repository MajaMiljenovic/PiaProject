import { Component, inject, OnInit } from '@angular/core';
import { RezervacijaService } from '../../services/rezervacija.service';
import { LocalizedString } from '@angular/compiler';
import { Korisnik } from '../../models/Korisnik';
import { Rezervacija } from '../../models/Rezervacija';
import { FormsModule } from '@angular/forms';
import { Vikendica } from '../../models/Vikendica';
import { VikendicaService } from '../../services/vikendica.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-rezervacije',
  standalone: true,
  imports: [FormsModule],
  templateUrl: './rezervacije.component.html',
  styleUrl: './rezervacije.component.css'
})
export class RezervacijeTuristaComponent implements OnInit{
  
  private rezervacijaService = inject(RezervacijaService);
  private vikendicaService = inject(VikendicaService)

  korisnik: Korisnik = new Korisnik();
  arhiva: Rezervacija[] = []
  rezervacije: Rezervacija[] = []
  recenzije: [number, number, boolean][] = []
  message: string = ""
  ostaviRecenzijuF: boolean = false;
  komentar: string = ""
  ocena = 0
  idRezervacijeA = 0;
  idRezervacijeR = 0;
  idVikendice = 0;
  rezervacija: Rezervacija = new Rezervacija();
  private router = inject(Router)
  msgDeleteRezervacijaUspesno: string = "";
  msgDeleteRezervacijaNeuspesno: string = "";

  ngOnInit(): void {
    const korisnikS = localStorage.getItem("korisnik");
    if(korisnikS){
      this.message = ""
      this.korisnik = JSON.parse(korisnikS);
    }
    else{
      alert("Doslo je do greske! Bicete vraceni na pocetnu stranicu.")
      localStorage.clear()
      this.router.navigate([''])
    }

    this.rezervacijaService.getArhiva(this.korisnik.korisnickoIme).subscribe( data => {
      if(data) {
        this.message = ""
        this.arhiva = data
      }
      else {
        this.message = "Nema rezervacija u arhivi.."
      }
    });

    this.rezervacijaService.getRezervacije(this.korisnik.korisnickoIme).subscribe( data => {
      if(data) {
        this.message = ""
        this.rezervacije = data
      }
      else {
        this.message = "Nema rezervacija u narednom periodu."
      }
    });
  }

  ostaviRezenziju(rezervacija:Rezervacija) {
    this.ostaviRecenzijuF = true;
    this.idRezervacijeA = rezervacija.idRezervacije;
    this.rezervacija = rezervacija;
  }

  odustani(){
    this.ostaviRecenzijuF = false;
  }

  onSubmit() {
    this.rezervacijaService.updateKomentarOcena(this.idRezervacijeA, this.komentar, this.ocena).subscribe( data => {
      if(data){
        this.message = ""
      }
      else{
        this.message = "Doslo je do greske."
      }
    });
    alert(this.ocena)
    this.vikendicaService.updateOcena(this.rezervacija.idVikendice).subscribe( data => {
      if(data){
        this.message = ""
        alert(data)
      }
      else {
        this.message = "Doslo je do greske."
      }
    });
    this.komentar = ""
    this.ocena = 0
    this.ostaviRecenzijuF = false;
    window.location.reload();
  }

  isOneDayAfterToday(date: Date): boolean {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    const inputDate = new Date(date);
    inputDate.setHours(0, 0, 0, 0);

    const diffInTime = inputDate.getTime() - today.getTime();
    const diffInDays = diffInTime / (1000 * 60 * 60 * 24);

    return diffInDays >= 1;
  }

  deleteRezervacija(idRezervacije:number){
    this.idRezervacijeR = idRezervacije;
    this.rezervacijaService.deleteRezervacija(this.idRezervacijeR).subscribe( data => {
      if(data){
        this.msgDeleteRezervacijaNeuspesno = ""
        this.msgDeleteRezervacijaUspesno = "Uspesno ste otkazali rezervaciju"
      }
      else{
        this.msgDeleteRezervacijaUspesno = ""
        this.msgDeleteRezervacijaNeuspesno = "Doslo je do greske. Niste uspeli da otkazete rezervaciju."
      }
    });
  }

}
