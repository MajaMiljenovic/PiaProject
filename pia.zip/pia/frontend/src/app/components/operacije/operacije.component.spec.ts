import { ComponentFixture, TestBed } from '@angular/core/testing';

import { OperacijeComponent } from './operacije.component';

describe('OperacijeComponent', () => {
  let component: OperacijeComponent;
  let fixture: ComponentFixture<OperacijeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [OperacijeComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(OperacijeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
