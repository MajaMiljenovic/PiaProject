import { Component, inject } from '@angular/core';
import { Admin } from '../../models/Admin';
import { Router } from '@angular/router';
import { AdminService } from '../../services/admin.service';
import { Korisnik } from '../../models/Korisnik';
import { Vikendica } from '../../models/Vikendica';

@Component({
  selector: 'app-operacije',
  standalone: true,
  imports: [],
  templateUrl: './operacije.component.html',
  styleUrl: './operacije.component.css'
})
export class OperacijeComponent {
  message = ""
  admin = new Admin()
  private router = inject(Router)
  private adminService = inject(AdminService)
  zahtevi: Korisnik[] = []
  vikendice: Vikendica[] = []
  turisti: Korisnik[] = []
  vlasnici: Korisnik[] = []
  loseVikendice: number[] = []

  ngOnInit(): void {
    const adminS = localStorage.getItem("admin")
    if(adminS){
      this.admin = JSON.parse(adminS)
    }
    else {
      alert("Doslo je do greske! Bicete vraceni na pocetnu stranicu.")
      localStorage.clear()
      this.router.navigate([''])
    }

    this.adminService.getZahtevi().subscribe( data => {
      if(data) {
        this.message = ""
        this.zahtevi = data
      }
      else {
        this.message = "Nema zahteva."
      }
    })

    this.adminService.getAllVikendiceAdmin().subscribe( data => {
      if(data) {
        this.message = ""
        this.vikendice = data
        /*this.adminService.getLose().subscribe( data => {
          if(data) {
            this.message = ""
            this.loseVikendice = data
          }
          else {
            this.message = "Nema zahteva."
          }
        })*/
      } 
      else {
        this.message = "Nema zahteva."
      }
    })

    this.adminService.getAllTuristi().subscribe( data => {
      if(data) {
        this.message = ""
        this.turisti = data
      }
      else {
        this.message = "Nema zahteva."
      }
    })

    this.adminService.getAllVlasnici().subscribe( data => {
      if(data) {
        this.message = ""
        this.vlasnici = data
      }
      else {
        this.message = "Nema zahteva."
      }
    })

  }

  logoutAdmin() {
    localStorage.clear();
    this.router.navigate([''])
  }

  prihvatiZahtev(korisnik:Korisnik){
    this.adminService.prihvatiZahtev(korisnik.korisnickoIme).subscribe( data => {
      if(data) {
        this.ngOnInit()
      }
      else {
        alert("Doslo je do greske pri registraciji novog korisnika! Stranica ce se automatski osveziti.")
        window.location.reload();
      }
    })
  }

  odbijZahtev(korisnik:Korisnik){
    this.adminService.odbijZahtev(korisnik.korisnickoIme).subscribe( data => {
      if(data) {
        this.ngOnInit()
      }
      else {
        alert("Doslo je do greske pri odbijanju registracije novog korisnika! Stranica ce se automatski osveziti.")
        window.location.reload();
      }
    })
  }

  deleteKorisnik(korisnik: Korisnik) {
   this.adminService.odbijZahtev(korisnik.korisnickoIme).subscribe( data => {
      if(data) {
        this.ngOnInit()
      }
      else {
        alert("Doslo je do greske pri brisanju korisnika! Stranica ce se automatski osveziti.")
        window.location.reload();
      }
    })
  }
  
  updateKorisnik(korisnik: Korisnik) {
    localStorage.setItem("korisnik", JSON.stringify(korisnik))
    this.router.navigate(['/admin/korisnik'])
  }
}
