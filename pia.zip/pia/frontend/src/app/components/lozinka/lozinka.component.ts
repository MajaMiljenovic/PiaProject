import { Component, OnInit, inject } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Korisnik } from '../../models/Korisnik';
import { AuthService } from '../../services/auth.service';
import { Admin } from '../../models/Admin';
import { Router } from '@angular/router';

@Component({
  selector: 'app-lozinka',
  standalone: true,
  imports: [FormsModule],
  templateUrl: './lozinka.component.html',
  styleUrl: './lozinka.component.css'
})
export class LozinkaComponent implements OnInit{

  staraLozinka = ""
  novaLozinka = ""
  potvrdaNoveLozinke = ""
  korisnik = new Korisnik()
  admin = new Admin()
  message = ""
  authService = inject(AuthService);
  router = inject(Router)
  msgNovaIPotvrda = ""
  msgStaraINova = ""
  msgLozinka = ""
  msgUspesno = ""

  ngOnInit(){
    if(localStorage.getItem("korisnik")){
      const korisnikS = localStorage.getItem("korisnik")
      if(korisnikS){
        this.korisnik = JSON.parse(korisnikS)
      }
      else{
        alert("Doslo je do greske! Bicete vraceni na pocetnu stranicu.")
        localStorage.clear()
        this.router.navigate([''])
      }
    }
    if(localStorage.getItem("admin")){
      const adminS = localStorage.getItem("admin")
      if(adminS){
        this.admin = JSON.parse(adminS)
      }
      else{
        alert("Doslo je do greske! Bicete vraceni na pocetnu stranicu.")
        localStorage.clear()
        this.router.navigate([''])
      }
    }
  }

  onSubmit() {
    if(this.staraLozinka != this.novaLozinka){
      this.msgStaraINova = ""
      if(this.checkLozinka(this.novaLozinka)){
        this.msgLozinka = ""
        if(this.novaLozinka == this.potvrdaNoveLozinke){
          this.msgNovaIPotvrda = ""
          if(localStorage.getItem("korisnik")){
            this.authService.changeLozinka(this.korisnik.korisnickoIme, this.staraLozinka, this.novaLozinka).subscribe( data => {
              if(data){
                this.message = ""
                alert("Uspesno ste promenili lozinku.")
                localStorage.clear()
                this.router.navigate([''])
              }
              else{
                alert("Doslo je do greske pri promeni lozinke.")
              }
            })
          }
          if(localStorage.getItem("admin")){
            this.authService.changeLozinkaAdmin(this.admin.korisnickoIme,this.staraLozinka, this.novaLozinka).subscribe( data => {
              if(data){
                this.message = ""
                alert("Uspesno ste promenili lozinku.")
                localStorage.clear()
                this.router.navigate([''])
              }
              else{
                alert("Doslo je do greske pri promeni lozinke.")
              }
            })
            
          }
        }else this.msgNovaIPotvrda = "Nova lozinka i potvrda nove lozinke nisu jedanke."
      }
    } else this.msgStaraINova = "Stara i nova lozinka ne smeju biti jednake."
  }


  checkLozinka(lozinka:string) : boolean {
    const regexLozinka = /^(?=[A-Za-z])(?=(?:.*[A-Z]))(?=(?:.*[a-z].*[a-z].*[a-z]))(?=(?:.*\d))(?=(?:.*[!@#$%^&*()_+.])).{6,10}$/;
   if(regexLozinka.test(lozinka)){
    this.msgLozinka = ""
    return true;
   }
   else{
    this.msgLozinka = `
        Lozinka ne ispunjava uslove.<br>
        Dužina: 6–10 karaktera.<br>
        Početak mora biti slovo (A-Z ili a-z).<br>
        Bar jedno veliko slovo (A-Z).<br>
        Bar tri mala slova (a-z).<br>
        Bar jedan broj (0-9).<br>
        Bar jedan specijalni karakter (npr. !@#$%^&*()_+.).
      `
      return false;
   }
  }

}
