import { AfterViewInit, Component, inject, OnInit } from '@angular/core';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { VikendicaService } from '../../services/vikendica.service';
import { Vikendica } from '../../models/Vikendica';

import * as L from 'leaflet';
import { Slika } from '../../models/Slika';
import { Komentar } from '../../models/Komentar';
import { FormsModule } from '@angular/forms';
import { Korisnik } from '../../models/Korisnik';


@Component({
  selector: 'app-vikendica',
  standalone: true,
  imports: [FormsModule],
  templateUrl: './vikendica.component.html',
  styleUrl: './vikendica.component.css',
})
export class VikendicaComponent implements OnInit {
  
  private route = inject(ActivatedRoute) 
  private vikendicaService = inject(VikendicaService)
  private router = inject(Router);
  
  message = ""
  map: L.Map | undefined;

  idVikendice: number = -1;
  slike:Slika[] = []
  komentari: Komentar[] = []
  korisnik: Korisnik = new Korisnik();
  vikendica:Vikendica = new Vikendica();

  odraslih = 0;
  dece = 0;
  cena: any;
  opis: any;
  datumOd: string = ""
  datumOdVreme: string = "14:00"
  datumDo: string = ""
  datumDoVreme: string = "10:00"
  messageGetAllKomentari: string = "";
  danas: Date = new Date();
  
  constructor() {}

  ngOnInit(): void {
    this.idVikendice = JSON.parse(this.route.snapshot.paramMap.get('idVikendice')!);
    this.getVikendica(this.idVikendice);
    this.getAllSlike(this.idVikendice);
    this.getAllKomentari(this.idVikendice);
    const korisnikS = localStorage.getItem("korisnik")
    if(korisnikS){
      this.message = ""
      this.korisnik = JSON.parse(korisnikS)
    }
    else {
      this.message = "Doslo je do greske"
    }

  }

  initMap(): void {
    if (!this.vikendica) return;
    this.map = L.map('map').setView([this.vikendica.lat, this.vikendica.lng], 15);
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      attribution: '&copy; OpenStreetMap contributors'
    }).addTo(this.map);
    L.marker([this.vikendica.lat, this.vikendica.lng])
      .addTo(this.map)
      .bindPopup(this.vikendica.naziv)
      .openPopup();
  }


  getVikendica(idVikendice: number) {
    this.vikendicaService.getVikdendica(idVikendice).subscribe( data => {
      if(data){
        this.message = ""
        this.vikendica = data;
        this.initMap();
      }
      else{
        this.message = "Doslo je do greske."
      }
    })
  }

  getAllSlike(idVikendice:number) {
    this.vikendicaService.getAllSlike(idVikendice).subscribe( data => {
      if(data){
        this.slike = data
      }
    });
  }

  getAllKomentari(idVikendice:number) {
      this.vikendicaService.getAllKomentari(idVikendice).subscribe( data => {
      if(data){
        this.messageGetAllKomentari = ""
        for(let i = 0; i < data.length; i++){
          data[i].index = i;
        }
        this.komentari = data;
      }
      else {
        this.messageGetAllKomentari = "Nema komentara."
      }
    });
  }

  incOdraslih() {
    this.odraslih++
  }
  decOdraslih() {
    if(this.odraslih-- <= 0) this.odraslih = 0
  }
  incDece() {
    this.dece++
  }
  decDece() {
    if(this.dece-- <= 0) this.dece = 0
  }
  
  onSubmit() {
    localStorage.setItem("datumOd", JSON.stringify(this.datumOd));
    localStorage.setItem("datumDo", JSON.stringify(this.datumDo));
    localStorage.setItem("odraslih", JSON.stringify(this.odraslih));
    localStorage.setItem("dece", JSON.stringify(this.dece));
    localStorage.setItem("vikendica", JSON.stringify(this.vikendica));
    this.router.navigate(['/turista/vikendice', this.vikendica.idVikendice, this.vikendica.naziv, 'rezervacija'])
  }


}
