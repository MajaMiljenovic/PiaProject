import { Component, inject } from '@angular/core';
import { Router, RouterLink, RouterOutlet } from '@angular/router';

@Component({
  selector: 'app-vlasnik',
  standalone: true,
  imports: [RouterOutlet, RouterLink],
  templateUrl: './vlasnik.component.html',
  styleUrl: './vlasnik.component.css'
})
export class VlasnikComponent {

  korisnik: any;
  message = ""
  
  private router = inject(Router)

  ngOnInit() {
    const korisnikS = localStorage.getItem("korisnik")
    if(korisnikS){
      this.message = ""
      this.korisnik = JSON.parse(korisnikS)
    }
    else {
      alert("Doslo je do greske! Bicete vraceni na pocetnu stranicu.")
      localStorage.clear()
      this.router.navigate([''])
    }
  }

  logoutKorisnik() {
    localStorage.clear();
    this.router.navigate([''])
  }
}
