import { Component, inject } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router, RouterLink } from "@angular/router";
import { PodaciComponent } from "../podaci/podaci.component";
import { AuthService } from '../../services/auth.service';
import { VikendiceTuristaComponent } from "../vikendiceTurista/vikendice.component";

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [RouterLink, FormsModule, PodaciComponent, VikendiceTuristaComponent],
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent {
  
  korisnickoIme = ""
  lozinka = ""
  messageOnInit = ""
  message = ""

  authService = inject(AuthService)
  router = inject(Router)


  onSubmit() {
    this.authService.loginKorisnik(this.korisnickoIme, this.lozinka).subscribe( data => {
      if(data) {
        if(data.aktivan == "da"){
          this.message = ""
          localStorage.setItem("korisnik", JSON.stringify(data))
          if(data.tip == "turista"){
            this.router.navigate(['/turista'])
          }
          if(data.tip == "vlasnik"){
            this.router.navigate(['/vlasnik'])
          }
        }
        else{
          this.message = "Administrator jos uvek nije prihvatio Vas zahtev za regisraciju."
        }
      }
      else {
        this.message = "Neispravno korisnicko ime ili lozinka."
      }
    })
  }

}
