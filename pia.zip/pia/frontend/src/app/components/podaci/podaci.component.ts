import { Component, inject, OnInit } from '@angular/core';
import { Podaci } from '../../models/Podaci';
import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-podaci',
  standalone: true,
  imports: [],
  templateUrl: './podaci.component.html',
  styleUrl: './podaci.component.css'
})
export class PodaciComponent implements OnInit{
  
  podaci = new Podaci();
  pocetnaService = inject(AuthService)
  messageOnInit = ""

  ngOnInit(): void {
    this.pocetnaService.getAllPodaci().subscribe( data => {
      if(data) {
        this.messageOnInit = ""
        this.podaci = data
      }
      else {
        this.messageOnInit = "Ne postoje vikendice."
      }
    })
  }
  
}
