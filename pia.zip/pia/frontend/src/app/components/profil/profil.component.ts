import { Component, inject, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { ProfilService } from '../../services/profil.service';
import { filter } from 'rxjs';
import { Korisnik } from '../../models/Korisnik';
import { Vikendica } from '../../models/Vikendica';

@Component({
  selector: 'app-profil',
  standalone: true,
  imports: [FormsModule],
  templateUrl: './profil.component.html',
  styleUrl: './profil.component.css'
})
export class ProfilComponent implements OnInit{

  korisnik: Korisnik = new Korisnik();
  
  message = ""
  msgDimenzija = ""
  msgSlika = ""
  msgKartica = ""
  msgMejl = ""

  private router = inject(Router)
  private profilService = inject(ProfilService)


  ngOnInit() {

    const korisnikS = localStorage.getItem("korisnik")
    if(korisnikS){
      this.message = ""
      this.korisnik = JSON.parse(korisnikS)
    }
    else {
      alert("Doslo je do greske! Bicete vraceni na pocetnu stranicu.")
      localStorage.clear()
      this.router.navigate([''])
    }
  }

  izmeniImeF= false;
  izmeniPrezimeF= false;
  izmeniAdresaF= false;
  izmeniMejlF= false;
  izmeniTelefonF= false;
  izmeniKarticaF= false;
  izmeniSlikaF= false;

  imeIzmena= ""
  prezimeIzmena= ""
  adresaIzmena= ""
  mejlIzmena=""
  telefonIzmena=""
  karticaIzmena=""
  slikaIzmena!: File;

  msgUpdate = ""

  onFileSelected(event: any) {
    const fajl: File = event.target.files[0];
    if (fajl) {
      this.slikaIzmena = fajl
    }
  }

  checkSlika(slika: File) : Promise<boolean> {
    return new Promise((resolve, reject) => {
      const img = new Image() 
      img.src = URL.createObjectURL(slika);
      img.onload = () => {
        const sirina = img.width;
        const visina = img.height;
        alert(sirina + " x " + visina)
        if (sirina >= 100 && sirina <= 300 && visina >= 100 && visina <= 300) {
          this.msgDimenzija = ""
          URL.revokeObjectURL(img.src);
          resolve(true);
        } else {
          this.msgDimenzija = "Slika nije dozvoljenih dimnezija. Slika mora biti u dimenziji 100x100 - 300x300."
          URL.revokeObjectURL(img.src);
          resolve(false);
        }
      }
    });
  }

  async sacuvajSlika() {
    this.korisnik.slika = this.slikaIzmena;
    let f = await this.checkSlika(this.korisnik.slika)
    if(f){
      this.profilService.updateSlika(this.korisnik.korisnickoIme, this.korisnik.slika).subscribe( data => {
        if(data){
          this.msgSlika = ""
          localStorage.setItem("korisnik", JSON.stringify(data))
        }
        else this.msgSlika = "Doslo je do greske prilikom cuvanja slike. Pokusajte ponovo."
      })
      this.izmeniSlikaF = false;
      this.ngOnInit();
    }
  }

  izmeniSlika() {
    this.izmeniSlikaF = true;
  }

  odustaniSlika(){
    this.izmeniSlikaF = false
  }

  checkKartica() : boolean {
    const regexDiners = /^(30[0-3]|36|38)\d{12}$/;
    const regexMaster = /^5[1-5]\d{14}$/;
    const regexVisa = /^(4539|4556|4916|4532|4929|4485|4716)\d{12}$/;
    if(regexDiners.test(this.korisnik.kartica)){
      return true;
    }
    if(regexMaster.test(this.korisnik.kartica)){
      return true;
    }
    if(regexVisa.test(this.korisnik.kartica)){
      return true;
    }
    else return false;
  }

  sacuvajKartica() {
    this.korisnik.kartica = this.karticaIzmena;
    let f = this.checkKartica()
    if(f){
      this.profilService.updateKartica(this.korisnik.korisnickoIme, this.korisnik.kartica).subscribe( data => {
      if(data){
        this.msgKartica = ""
        localStorage.setItem("korisnik", JSON.stringify(data))
      }
      else alert("Doslo je do greske prilikom cuvanja kartice.")
    })
    this.izmeniKarticaF = false;
    }
    else {
      this.msgKartica = "Kartica ne postoji. Unesite validnu karticu."
    }
    
  }

  izmeniKartica() {
    this.izmeniKarticaF = true;
  }

  odustaniKartica(){
    this.izmeniKarticaF = false
  }

  sacuvajTelefon() {
    this.korisnik.telefon = this.telefonIzmena;
    this.profilService.updateTelefon(this.korisnik.korisnickoIme, this.korisnik.telefon).subscribe( data => {
      if(data){
        this.msgUpdate = ""
        localStorage.setItem("korisnik", JSON.stringify(data))
      }
      else this.msgUpdate = "Nesto ne valja."
    })
    this.izmeniTelefonF = false;
    this.ngOnInit()
  }

  izmeniTelefon() {
    this.izmeniTelefonF = true;
  }

  odustaniTelefon(){
    this.izmeniTelefonF = false
  }

  checkEmail(email: string): boolean {
    const regex = /^[a-z0-9._]+@[a-z0-9.-]+\.[a-z]{2,}$/;
    return regex.test(email);
  }

  sacuvajMejl() {
    let f = this.checkEmail(this.mejlIzmena)
    if(f){
      this.profilService.updateMejl(this.korisnik.korisnickoIme, this.mejlIzmena).subscribe( data => {
      if(data){
        this.msgMejl = ""
        this.korisnik.mejl = this.mejlIzmena;
        localStorage.setItem("korisnik", JSON.stringify(data))
        this.izmeniMejlF = false;
      }
      else this.msgMejl = "Korisnik sa zadatim mejlom vec postoji."
    })
    
    }
  }

  izmeniMejl() {
    this.izmeniMejlF = true;
  }

  odustaniMejl(){
    this.izmeniMejlF = false
  }


  sacuvajAdresa() {
    this.korisnik.adresa = this.adresaIzmena;
    this.profilService.updateAdresa(this.korisnik.korisnickoIme, this.korisnik.adresa).subscribe( data => {
      if(data){
        this.msgUpdate = ""
        localStorage.setItem("korisnik", JSON.stringify(data))
      }
      else this.msgUpdate = "Nesto ne valja."
    })
    this.izmeniAdresaF = false;
  }


  izmeniAdresa() {
    this.izmeniAdresaF = true;
  }

  odustaniAdresa(){
    this.izmeniAdresaF = false
  }


  sacuvajPrezime() {
    this.korisnik.prezime = this.prezimeIzmena;
    this.profilService.updatePrezime(this.korisnik.korisnickoIme, this.korisnik.prezime).subscribe( data => {
      if(data){
        this.msgUpdate = ""
        localStorage.setItem("korisnik", JSON.stringify(data))
      }
      else this.msgUpdate = "Nesto ne valja."
    })
    this.izmeniPrezimeF = false;
  }


  izmeniPrezime() {
    this.izmeniPrezimeF = true;
  }

  odustaniPrezime(){
    this.izmeniPrezimeF = false
  }


  sacuvajIme() {
    this.korisnik.ime = this.imeIzmena;
    this.profilService.updateIme(this.korisnik.korisnickoIme, this.korisnik.ime).subscribe( data => {
      if(data){
        this.msgUpdate = ""
        localStorage.setItem("korisnik", JSON.stringify(data))
      }
      else this.msgUpdate = "Nesto ne valja."
    })
    this.izmeniImeF = false;
  }


  izmeniIme() {
    this.izmeniImeF = true;
  }

  odustaniIme(){
    this.izmeniImeF = false
  }

}
