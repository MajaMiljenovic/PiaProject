import { Component, inject } from '@angular/core';
import { Router, RouterLink } from '@angular/router';

import { FormsModule } from '@angular/forms';
import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-login-admin',
  standalone: true,
  imports: [FormsModule],
  templateUrl: './login-admin.component.html',
  styleUrl: './login-admin.component.css'
})
export class LoginAdminComponent {
  korisnickoIme = ""
  lozinka = ""
  message = ""
  private router = inject(Router)
  private authService = inject(AuthService)

  onSubmit() {
    this.authService.loginAdmin(this.korisnickoIme, this.lozinka).subscribe( data => {
      if(data) {
        this.message = ""
        localStorage.setItem("admin", JSON.stringify(data))
        this.router.navigate(['/admin'])
      }
      else {
        this.message = "Neispravno korisnicko ime ili lozinka."
      }
    })
  }
}
