import { Component, inject, OnInit } from '@angular/core';
import { Korisnik } from '../../models/Korisnik';
import { Vikendica } from '../../models/Vikendica';
import { ProfilService } from '../../services/profil.service';
import { FormsModule } from '@angular/forms';
import { DatePipe } from '@angular/common';
import { RezervacijaService } from '../../services/rezervacija.service';
import { Rezervacija } from '../../models/Rezervacija';
import { Router } from '@angular/router';

@Component({
  selector: 'app-rezervacija',
  standalone: true,
  imports: [FormsModule, DatePipe],
  templateUrl: './rezervacija.component.html',
  styleUrl: './rezervacija.component.css'
})
export class RezervacijaComponent implements OnInit{

  private profilService = inject(ProfilService);
  private rezervacijaService = inject(RezervacijaService);
  private router = inject(Router);

  message: string = "";
  korisnik: Korisnik = new Korisnik();
  vikendica: Vikendica = new Vikendica();
  rezervacija: Rezervacija = new Rezervacija();
  datumOd: any;
  datumDo: any;
  odraslih: number = 0;
  dece: number = 0;
  karticaIzmena: string = "";
  izmeniKarticaF: boolean = false;
  cena: number = 0;
  opis: string = "";

  ngOnInit() {
    const korisnikS = localStorage.getItem("korisnik")
    if(korisnikS){
      this.message = ""
      this.korisnik = JSON.parse(korisnikS)
    }
    else {
      alert("Doslo je do greske! Bicete vraceni na pocetnu stranicu.")
      localStorage.clear()
      this.router.navigate([''])
    }

    const vikendicaS = localStorage.getItem("vikendica")
    if(vikendicaS){
      this.message = ""
      this.vikendica = JSON.parse(vikendicaS)
    }
    else {
      this.message = "Doslo je do greske: Vikendica"
    }

    const datumOdS = localStorage.getItem("datumOd")
    if(datumOdS){
      this.message = ""
      this.datumOd = JSON.parse(datumOdS)
      this.datumOd = new Date(this.datumOd)
    }
    else {
      this.message = "Doslo je do greske: Vikendica"
    }

    const datumDoS = localStorage.getItem("datumDo")
    if(datumDoS){
      this.message = ""
      this.datumDo = JSON.parse(datumDoS)
      this.datumDo = new Date(this.datumDo)
    }
    else {
      this.message = "Doslo je do greske: Vikendica"
    }

    const odraslihS = localStorage.getItem("odraslih")
    if(odraslihS){
      this.message = ""
      this.odraslih = JSON.parse(odraslihS)
    }
    else {
      this.message = "Doslo je do greske: Vikendica"
    }

    const deceS = localStorage.getItem("dece")
    if(deceS){
      this.message = ""
      this.dece = JSON.parse(deceS)
    }
    else {
      this.message = "Doslo je do greske: Vikendica"
    }

    let cena
    let danas = new Date()
    if(danas.getMonth() + 1 >= 4 && danas.getMonth() + 1 <= 9){
      cena = this.vikendica.cenaLeto
    }
    else{
      cena = this.vikendica.cenaZima
    }

    this.cena = ((this.datumDo.getTime() - this.datumOd.getTime()) / (1000 * 60 * 60 * 24)) * cena;
  }

  sacuvajKartica() {
    this.korisnik.kartica = this.karticaIzmena;
    this.profilService.updateKartica(this.korisnik.korisnickoIme, this.korisnik.kartica).subscribe( data => {
      if(data){
        localStorage.setItem("korisnik", JSON.stringify(data))
        this.korisnik = data
      }
    })
    this.izmeniKarticaF = false;
  }

  izmeniKartica() {
    this.izmeniKarticaF = true;
  }

  odustaniKartica(){
    this.izmeniKarticaF = false
  }

  onSubmit() {
    this.rezervacijaService.checkDatum(this.datumOd, this.datumDo).subscribe( data => {
      if(data == true){
        this.rezervacijaService.insertRezervacija(
          this.vikendica.idVikendice,
          this.vikendica.korisnickoImeVlasnika,
          this.korisnik.korisnickoIme,
          new Date(),
          this.datumOd,
          this.datumDo,
          this.odraslih,
          this.dece,
          this.cena,
          this.vikendica.naziv,
          this.vikendica.mesto
        ).subscribe( bata => {
          if(bata) {
            this.rezervacija = bata;
            alert("Uspesno ste napravili rezervaciju.")
            this.router.navigate(['/turista/vikendice'])
          }
          else {
            this.message = "Doslo je do greske."
          }
        });
      }
      else{
        this.message = "Vikendica " + this.vikendica.naziv + " je vec rezervisana u datom periodu."
      }
    });
  }

}
