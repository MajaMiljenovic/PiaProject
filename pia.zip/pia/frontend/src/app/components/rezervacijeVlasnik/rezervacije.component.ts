import { Component, inject, OnInit } from '@angular/core';
import { Korisnik } from '../../models/Korisnik';
import { Rezervacija } from '../../models/Rezervacija';
import { RezervacijaService } from '../../services/rezervacija.service';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-rezervacije',
  standalone: true,
  imports: [FormsModule],
  templateUrl: './rezervacije.component.html',
  styleUrl: './rezervacije.component.css'
})
export class RezervacijeVlasnikComponent implements OnInit{


  message = ""
  korisnik: Korisnik = new Korisnik()
  neobradjeneRezervacije: Rezervacija[] = []
  private rezervacijaService = inject(RezervacijaService)
  id = -1
  razlog = ""
  private router = inject(Router)


  ngOnInit(): void {
    const korisnikS = localStorage.getItem("korisnik");
    if(korisnikS){
      this.message = ""
      this.korisnik = JSON.parse(korisnikS);
    }
    else{
      alert("Doslo je do greske! Bicete vraceni na pocetnu stranicu.")
      localStorage.clear()
      this.router.navigate([''])
    }

    this.rezervacijaService.getNeobradjeneRezervacije(this.korisnik.korisnickoIme).subscribe( data => {
      if(data) {
        this.message = ""
        this.neobradjeneRezervacije = data
      }
      else {
        this.message = "Nema rezervacija u narednom periodu."
      }
    });
  }

  odustani() {
    this.id = -1
  }

  potvrdiOdbijanje(idRezervacije:number) {
    this.rezervacijaService.odbijRezervaciju(idRezervacije, this.razlog).subscribe( data => {
      if(data) {
        this.message = ""
        this.razlog = ""
        window.location.reload();
      }
      else {
        this.message = "Nema rezervacije."
      }
    });
  } 

  odbij(id:number) {
    this.id = id;
  }

  prihvati(idRezervacije:number) {
    this.rezervacijaService.prihvatiRezervaciju(idRezervacije).subscribe( data => {
      if(data == 2) {
        this.message = ""
        window.location.reload();
      }
      else {
        this.message = "Nema rezervacije."
      }
    });
  }
  
}
