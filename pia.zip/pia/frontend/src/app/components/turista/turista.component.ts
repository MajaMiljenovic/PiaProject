import { Component, inject, OnInit } from '@angular/core';
import { Korisnik } from '../../models/Korisnik';
import { Router, RouterLink, RouterOutlet } from '@angular/router';

@Component({
  selector: 'app-turista',
  standalone: true,
  imports: [RouterLink, RouterOutlet],
  templateUrl: './turista.component.html',
  styleUrl: './turista.component.css'
})
export class TuristaComponent {

  router = inject(Router);

  logoutKorisnik() {
    localStorage.clear();
    this.router.navigate([''])
  }

}
