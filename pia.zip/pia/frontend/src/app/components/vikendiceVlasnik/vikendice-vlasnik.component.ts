import { Component, inject, OnInit } from '@angular/core';
import { Korisnik } from '../../models/Korisnik';
import { Vikendica } from '../../models/Vikendica';
import { VikendicaService } from '../../services/vikendica.service';
import { FormsModule } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { Slika } from '../../models/Slika';

@Component({
  selector: 'app-vikendice-vlasnik',
  standalone: true,
  imports: [FormsModule, RouterLink],
  templateUrl: './vikendice-vlasnik.component.html',
  styleUrl: './vikendice-vlasnik.component.css'
})
export class VikendiceVlasnikComponent implements OnInit{

  korisnik:Korisnik = new Korisnik();
  message=""
  private vikendicaService = inject(VikendicaService)
  private router =inject(Router)
  vikendice: Vikendica[] = []
  vikendica: Vikendica = new Vikendica()
  slike: File[] = []
  urls: string[] = []
  praveSlike: Slika[] = []

  nazivF = false
  mestoF = false
  opisF = false
  cenaLetoF = false
  cenaZimaF = false
  telefonF = false
  latF = false
  lngF = false
  
  naziv = ""
  mesto = ""
  opis = ""
  cenaLeto = 0
  cenaZima = 0
  telefon = ""
  lat = 0
  lng = 0

  idVikendice = -1

  ngOnInit(): void {
    const korisnikS = localStorage.getItem("korisnik");
    if(korisnikS){
      this.message = ""
      this.korisnik = JSON.parse(korisnikS);
      this.vikendicaService.getMojeVikendice(this.korisnik.korisnickoIme).subscribe( data => {
        if(data) {
          this.message = ""
          this.vikendice = data
        }
        else {
          this.message = "Doslo je do greske."
        }
      });

    }
    else{
      alert("Doslo je do greske! Bicete vraceni na pocetnu stranicu.")
      localStorage.clear()
      this.router.navigate([''])
    }
  }

  onSubmit(){
    this.vikendica.korisnickoImeVlasnika = this.korisnik.korisnickoIme
    this.vikendicaService.insertVikendica(this.vikendica).subscribe( data => {
        if(data != 0) {
          this.vikendica.idVikendice = data
          this.vikendicaService.insertGalerija(this.vikendica.idVikendice, this.slike).subscribe( data => {
            if(data){
              this.ngOnInit();
            }
          });
        }
        else {
          this.message = "Doslo je do greske."
        }
      });
  }

  onFileSelected(event: any) {
    const files: FileList = event.target.files;
    if (files && files.length > 0) {
      this.slike = Array.from(files);
      this.urls = [];
      this.slike.forEach(file => {
        const objectUrl = URL.createObjectURL(file);
        this.urls.push(objectUrl);
      });

    }
  }

  obrisiVikendicu(idVikendice:number){
    this.vikendicaService.obrisiVikendicu(idVikendice).subscribe( data => {
      if(data > 0){
        this.ngOnInit();
      }
    });
  }

  

}


