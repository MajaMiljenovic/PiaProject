import { Component, inject } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { AuthService } from '../../services/auth.service';
import { Korisnik } from '../../models/Korisnik';
import { PodaciComponent } from "../podaci/podaci.component";
import { VikendiceTuristaComponent } from "../vikendiceTurista/vikendice.component";
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-register',
  standalone: true,
  imports: [FormsModule, RouterLink, PodaciComponent, VikendiceTuristaComponent],
  templateUrl: './register.component.html',
  styleUrl: './register.component.css'
})
export class RegisterComponent {

  
  private authSrvice = inject(AuthService)

  private router = inject(Router);
  msgOnInit = ""
  msgCheckInputs = ""
  msgKredencijali = ""
  msgLozinka = ""
  msgKartica = ""
  msgDimenzija = ""
  msgMejl = ""

  kartica = "";

  korisnik = new Korisnik();

  async onSubmit() {
    if(await this.checkInputs()){
      this.msgCheckInputs = ""
      if(this.checkLozinka()){
        this.msgLozinka = ""
        if(this.checkEmail()){
          this.msgMejl = ""
          if(this.checkKartica()) {
            this.msgKartica = ""
            this.authSrvice.registerKorisnik(this.korisnik).subscribe( data => {
              if(data) {
                this.msgKredencijali = ""
                if(data.aktivan == "da"){
                  localStorage.setItem("korisnik", JSON.stringify(data))
                  if(data.tip == "turista"){
                    this.router.navigate(['/turista'])
                  }
                  if(data.tip == "vlasnik"){
                    this.router.navigate(['/vlasnik'])
                  }
                }
                else {
                  alert("Ceka se odobrenje administratora za kreiranje Vaseg naloga.")
                  this.router.navigate(['/pocetna/login'])
                }
                  
              }
              else {
                this.msgKredencijali = "Korisnik sa zadatim kredencijalima vec postoji u sistemu."
              }
            })
          }
          else {
            this.msgKartica = "Broj kredite kartice nije ispravan.";
          }
        }
        else {
          this.msgMejl = "Neispravna e-mail adresa."
        }
      }
    }
    else {
      this.msgCheckInputs = "Sva polja oznacena sa * su obavezna"
    }
    
  }

  checkLozinka() : boolean {
    const regexLozinka = /^(?=[A-Za-z])(?=(?:.*[A-Z]))(?=(?:.*[a-z].*[a-z].*[a-z]))(?=(?:.*\d))(?=(?:.*[!@#$%^&*()_+.])).{6,10}$/;
   if(regexLozinka.test(this.korisnik.lozinka)){
    this.msgLozinka = ""
    return true;
   }
   else{
    this.msgLozinka = `
        Lozinka ne ispunjava uslove.<br>
        Dužina: 6–10 karaktera.<br>
        Početak mora biti slovo (A-Z ili a-z).<br>
        Bar jedno veliko slovo (A-Z).<br>
        Bar tri mala slova (a-z).<br>
        Bar jedan broj (0-9).<br>
        Bar jedan specijalni karakter (npr. !@#$%^&*()_+.).
      `
      return false;
   }
  }

  checkEmail(): boolean {
    const regex = /^[a-z0-9._]+@[a-z0-9.-]+\.[a-z]{2,}$/;
    return regex.test(this.korisnik.mejl);
  }

  checkKartica() : boolean {
    const regexDiners = /^(30[0-3]|36|38)\d{12}$/;
    const regexMaster = /^5[1-5]\d{14}$/;
    const regexVisa = /^(4539|4556|4916|4532|4929|4485|4716)\d{12}$/;
    if(regexDiners.test(this.korisnik.kartica)){
      this.msgKartica = "";
      this.kartica = "diners.png"
      return true;
    }
    if(regexMaster.test(this.korisnik.kartica)){
      this.msgKartica = "";
      this.kartica = "master.png"
      return true;
    }
    if(regexVisa.test(this.korisnik.kartica)){
      this.msgKartica = "";
      this.kartica = "visa.png"
      return true;
    }
    return false;
  }

  checkSlika() : Promise<boolean> {
     return new Promise((resolve, reject) => {
      const img = new Image() 
      img.src = URL.createObjectURL(this.korisnik.slika);
      img.onload = () => {
        const sirina = img.width;
        const visina = img.height;
        if (sirina >= 100 && sirina <= 300 && visina >= 100 && visina <= 300) {
          this.msgDimenzija = ""
          URL.revokeObjectURL(img.src);
          resolve(true);
        } else {
          this.msgDimenzija = "Slika nije dozvoljenih dimnezija. Slika mora biti u dimenziji 100x100 - 300x300."
          URL.revokeObjectURL(img.src);
          resolve(false);
        }
      }
    });
  }

  async checkInputs(){
    let f;
    if(this.korisnik.slika == null) {
      const response = await fetch('default.jpg');
      const blob = await response.blob();
      this.korisnik.slika = new File([blob], 'default-profile.png', { type: blob.type });
    }
    else{
      f = await this.checkSlika()
    }
    if(
      this.korisnik.adresa != "" &&
      this.korisnik.ime != "" &&
      this.korisnik.kartica != "" &&
      this.korisnik.korisnickoIme != "" &&
      this.korisnik.lozinka != "" &&
      this.korisnik.mejl != "" &&
      this.korisnik.pol != "" &&
      this.korisnik.prezime != "" &&
      this.korisnik.telefon != "" &&
      this.korisnik.tip != ""
    ){
      return true
    }
    else {
      return false
    } 
  }

  onFileSelected(event: any) {
    const fajl: File = event.target.files[0];
    if (fajl) {
      this.korisnik.slika = fajl;
    }
  }

}
