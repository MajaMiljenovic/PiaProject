import { ComponentFixture, TestBed } from '@angular/core/testing';

import { VikendicaVlasnikComponent } from './vikendica-vlasnik.component';

describe('VikendicaVlasnikComponent', () => {
  let component: VikendicaVlasnikComponent;
  let fixture: ComponentFixture<VikendicaVlasnikComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [VikendicaVlasnikComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(VikendicaVlasnikComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
