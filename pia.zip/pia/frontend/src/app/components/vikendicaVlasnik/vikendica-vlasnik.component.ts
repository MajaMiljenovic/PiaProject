import { Component, inject, OnInit } from '@angular/core';
import { Korisnik } from '../../models/Korisnik';
import { ActivatedRoute, Router } from '@angular/router';
import { VikendicaService } from '../../services/vikendica.service';
import { Slika } from '../../models/Slika';
import { Komentar } from '../../models/Komentar';
import { Vikendica } from '../../models/Vikendica';
//import L from 'leaflet';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-vikendica-vlasnik',
  standalone: true,
  imports: [FormsModule],
  templateUrl: './vikendica-vlasnik.component.html',
  styleUrl: './vikendica-vlasnik.component.css'
})
export class VikendicaVlasnikComponent implements OnInit{

  idVikendice:number = -1

  private route = inject(ActivatedRoute) 
  private vikendicaService = inject(VikendicaService)
  private router = inject(Router);
  
  message = ""
  map: L.Map | undefined;

  slike:Slika[] = []
  komentari: Komentar[] = []
  korisnik: Korisnik = new Korisnik();
  vikendica:Vikendica = new Vikendica();
  vikendice: Vikendica[] = []
  urls: string[] = []
  slikeFile: File[] = []

  nazivF = false
  mestoF = false
  opisF = false
  cenaLetoF = false
  cenaZimaF = false
  telefonF = false
  latF = false
  lngF = false
  slikaF = false
  
  naziv = ""
  mesto = ""
  opis = ""
  cenaLeto = 0
  cenaZima = 0
  telefon = ""
  lat = 0
  lng = 0
  slika = null


  ngOnInit(): void {
    this.idVikendice = JSON.parse(this.route.snapshot.paramMap.get('idVikendice')!);
    this.getVikendica(this.idVikendice);
    this.getAllSlike(this.idVikendice);
    const korisnikS = localStorage.getItem("korisnik")
    if(korisnikS){
      this.message = ""
      this.korisnik = JSON.parse(korisnikS)
    }
    else {
      this.message = "Doslo je do greske"
    }

  }

  /*initMap(): void {
    if (!this.vikendica) return;
    this.map = L.map('map').setView([this.vikendica.lat, this.vikendica.lng], 15);
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      attribution: '&copy; OpenStreetMap contributors'
    }).addTo(this.map);
    L.marker([this.vikendica.lat, this.vikendica.lng])
      .addTo(this.map)
      .bindPopup(this.vikendica.naziv)
      .openPopup();
  }*/


  getVikendica(idVikendice: number) {
    this.vikendicaService.getVikdendica(idVikendice).subscribe( data => {
      if(data){
        this.message = ""
        this.vikendica = data;
        //this.initMap();
      }
      else{
        this.message = "Doslo je do greske."
      }
    })
  }

  getAllSlike(idVikendice:number) {
    this.vikendicaService.getAllSlike(idVikendice).subscribe( data => {
      if(data){
        this.slike = data
      }
    });
  }

  getOcenaImage(ocena: number): string {
    if (ocena <= 0) return 'stars/0.jpg';
    if (ocena < 0.75) return 'stars/05.png';
    if (ocena < 1.25) return 'stars/1.png';
    if (ocena < 1.75) return 'stars/15.png';
    if (ocena < 2.25) return 'stars/2.png';
    if (ocena < 2.75) return 'stars/25.png';
    if (ocena < 3.25) return 'stars/3.png';
    if (ocena < 3.75) return 'stars/35.png';
    if (ocena < 4.25) return 'stars/4.png';
    if (ocena < 4.75) return 'stars/45.png';
    return 'stars/5.jpg';
  }

  izmeniNaziv() {
    this.nazivF=true
  }
  izmeniMesto() {
    this.mestoF=true
  }
  izmeniOpis(){
    this.opisF=true
  }
  izmeniCenaLeto(){
    this.cenaLetoF=true
  }
  izmeniCenaZima(){
    this.cenaZimaF=true
  }
  izmeniTelefon(){
    this.telefonF=true
  }
  izmeniLat(){
    this.latF=true
  }
  izmeniLng(){
    this.lngF=true
  }
  izmeniSlika(){
    this.slikaF=true
  }

  sacuvajNaziv(idVikendice:number){
    this.vikendicaService.updateNaziv(idVikendice, this.naziv).subscribe( data => {
      if(data){
        this.ngOnInit()
      }
      else{
        this.message = "Greska"
      }
    })
  }
  sacuvajMesto(idVikendice:number){
    this.vikendicaService.updateMesto(idVikendice, this.mesto).subscribe( data => {
      if(data){
        this.ngOnInit()
      }
      else{
        this.message = "Greska"
      }
    })
  }
  sacuvajOpis(idVikendice:number){
    this.vikendicaService.updateOpis(idVikendice, this.opis).subscribe( data => {
      if(data){
        this.ngOnInit()
      }
      else{
        this.message = "Greska"
      }
    })
  }
  sacuvajTelefon(idVikendice:number){
    this.vikendicaService.updateTelefon(idVikendice, this.telefon).subscribe( data => {
      if(data){
        this.ngOnInit()
      }
      else{
        this.message = "Greska"
      }
    })
  }
  sacuvajCenaLeto(idVikendice:number){
    this.vikendicaService.updateCenaLeto(idVikendice, this.cenaLeto).subscribe( data => {
      if(data){
        this.ngOnInit()
      }
      else{
        this.message = "Greska"
      }
    })
  }
  sacuvajCenaZima(idVikendice:number){
    this.vikendicaService.updateCenaZima(idVikendice, this.cenaZima).subscribe( data => {
      if(data){
        this.ngOnInit()
      }
      else{
        this.message = "Greska"
      }
    })
  }
  sacuvajLat(idVikendice:number){
    this.vikendicaService.updateLat(idVikendice, this.lat).subscribe( data => {
      if(data){
        this.ngOnInit()
      }
      else{
        this.message = "Greska"
      }
    })
  }
  sacuvajLng(idVikendice:number){
    this.vikendicaService.updateLng(idVikendice, this.lng).subscribe( data => {
      if(data){
        this.ngOnInit()
      }
      else{
        this.message = "Greska"
      }
    })
  }
  sacuvajSlika(){
    this.vikendicaService.insertGalerija(this.vikendica.idVikendice, this.slikeFile).subscribe( data => {
      if(data){
        this.ngOnInit();
      }
      else{
        this.message = "Greska"
      }
    });
  }

  deleteSlika(slikaBrisanje: Slika) {
    this.vikendicaService.deleteSlika(slikaBrisanje).subscribe( data => {
      if(data > 0){
        this.ngOnInit();
      }
      else{
        this.message = "Greska"
      }
    });
  }

  onFileSelected(event: any) {
    const files: FileList = event.target.files;
    if (files && files.length > 0) {
      this.slikeFile = Array.from(files);
      this.urls = [];
      this.slikeFile.forEach(file => {
        const objectUrl = URL.createObjectURL(file);
        this.urls.push(objectUrl);
      });

    }
  }

  odustaniNaziv(){
    this.nazivF = false
    this.naziv = ""
  }
  odustaniMesto(){
    this.mestoF = false
    this.mesto = ""
  }
  odustaniOpis(){
    this.opisF = false
    this.opis = ""
  }
  odustaniTelefon(){
    this.telefonF = false
    this.telefon = ""
  }
  odustaniCenaLeto(){
    this.cenaLetoF = false
    this.cenaLeto = 0
  }
  odustaniCenaZima(){
    this.cenaZimaF = false
    this.cenaZima = 0
  }
  odustaniLat(){
    this.latF = false
    this.lat = 0
  }
  odustaniLng(){
    this.lngF = false
    this.lng = 0
  }
  odustaniSlika(){
    this.slikaF = false
    this.slika = null
  }

}