import { Component, inject, OnInit } from '@angular/core';
import { VikendicaService } from '../../services/vikendica.service';
import { Vikendica } from '../../models/Vikendica';
import { FormsModule } from '@angular/forms';
import { Router, RouterLink, RouterModule } from '@angular/router';

@Component({
  selector: 'app-vikendice',
  standalone: true,
  imports: [FormsModule, RouterLink, RouterModule],
  templateUrl: './vikendice.component.html',
  styleUrl: './vikendice.component.css'
})
export class VikendiceTuristaComponent implements OnInit{

  private vikendicaService = inject(VikendicaService)
  vikendice: Vikendica[] = [];
  messageOnInit = ""
  naziv = ""
  mesto = ""
  select = "nazivasc"
  flagTurista: any;
  private router = inject(Router)



  ngOnInit(): void {
    this.getAllVikendice(this.select, this.naziv, this.mesto);
    this.flagTurista = this.router.url.includes('turista');
  }

  onSubmit() {
    this.getAllVikendice(this.select, this.naziv, this.mesto)
  }

  getAllVikendice(select:string, naziv:string, mesto:string){
    this.vikendicaService.getAllVikendice(select, naziv, mesto).subscribe( data => {
      if(data) {
        this.messageOnInit = ""
        this.vikendice = data
      }
      else {
        this.messageOnInit = "Doslo je do greske."
      }
    });
  }

  getOcenaImage(ocena: number): string {
    if (ocena <= 0) return 'stars/0.jpg';
    if (ocena < 0.75) return 'stars/05.png';
    if (ocena < 1.25) return 'stars/1.png';
    if (ocena < 1.75) return 'stars/15.png';
    if (ocena < 2.25) return 'stars/2.png';
    if (ocena < 2.75) return 'stars/25.png';
    if (ocena < 3.25) return 'stars/3.png';
    if (ocena < 3.75) return 'stars/35.png';
    if (ocena < 4.25) return 'stars/4.png';
    if (ocena < 4.75) return 'stars/45.png';
    return 'stars/5.jpg';
  }

}
