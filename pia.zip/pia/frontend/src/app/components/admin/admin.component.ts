import { Component, inject, OnInit } from '@angular/core';
import { Router, RouterLink, RouterOutlet } from '@angular/router';
import { Admin } from '../../models/Admin';

@Component({
  selector: 'app-admin',
  standalone: true,
  imports: [RouterOutlet, RouterLink],
  templateUrl: './admin.component.html',
  styleUrl: './admin.component.css'
})
export class AdminComponent implements OnInit{

  admin: Admin = new Admin()

  private router = inject(Router)

  ngOnInit(): void {
      const adminS = localStorage.getItem("admin")
      if(adminS){
        this.admin = JSON.parse(adminS)
      }
      else {
        alert("Doslo je do greske! Bicete vraceni na pocetnu stranicu.")
        localStorage.clear()
        this.router.navigate([''])
      }
  }

  logoutAdmin() {
    localStorage.clear();
    this.router.navigate([''])
  }

}
