import { HttpClient } from '@angular/common/http';
import { inject, Injectable } from '@angular/core';
import { Korisnik } from '../models/Korisnik';

@Injectable({
  providedIn: 'root'
})
export class ProfilService {

  constructor() { }

  private http = inject(HttpClient)
  private url = "http://localhost:8080/profil"

  updateIme(korisnickoIme: string, ime: string) {
    return this.http.post<Korisnik>(`${this.url}/update-ime`, {}, { params: {korisnickoIme, ime} });
  }

  updatePrezime(korisnickoIme: string, prezime: string) {
    return this.http.post<Korisnik>(`${this.url}/update-prezime`, {}, { params: {korisnickoIme:korisnickoIme, prezime:prezime} });
  }

  updateAdresa(korisnickoIme: string, adresa: string) {
    return this.http.post<Korisnik>(`${this.url}/update-adresa`, {}, { params: {korisnickoIme, adresa} });
  }

  updateMejl(korisnickoIme: string, mejl: string) {
    return this.http.post<Korisnik>(`${this.url}/update-mejl`, {}, { params: {korisnickoIme, mejl} });
  }

  updateTelefon(korisnickoIme: string, telefon: string) {
    return this.http.post<Korisnik>(`${this.url}/update-telefon`, {}, { params: {korisnickoIme, telefon} });
  }

  updateKartica(korisnickoIme: string, kartica: string) { 
    return this.http.post<Korisnik>(`${this.url}/update-kartica`, {}, { params: {korisnickoIme, kartica} });
  }
  
  updateSlika(korisnickoIme: string, slika: File) {
    const formData = new FormData();
    formData.append("korisnickoIme", korisnickoIme)
    formData.append("slika", slika, slika.name);
    return this.http.post<Korisnik>(`${this.url}/update-slika`, formData)
  }
}
