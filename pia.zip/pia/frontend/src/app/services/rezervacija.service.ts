import { HttpClient, HttpParams } from '@angular/common/http';
import { inject, Injectable } from '@angular/core';
import { combineAll } from 'rxjs';
import { Rezervacija } from '../models/Rezervacija';

@Injectable({
  providedIn: 'root'
})
export class RezervacijaService {

  constructor() { }

  private http = inject(HttpClient);
  private url = "http://localhost:8080/rezervacija";

  checkDatum(odDatuma:Date, doDatuma:Date){
    const od = odDatuma.toISOString().split('T')[0];
    const dO = doDatuma.toISOString().split('T')[0];
    return this.http.get<boolean>(`${this.url}/${od}/${dO}`);
  }

  insertRezervacija(
    idVikendice: number, 
    korisnickoImeVlasnika: string, 
    korisnickoImeTuriste: string,
    vremeRezervacije: Date, 
    odDatuma: any, 
    doDatuma: any, 
    brojOdraslih: number, 
    brojDece: number, 
    cena: number,
    nazivVikendice: string,
    mesto: string
  ) {
    const data = {
      idVikendice:idVikendice,
      korisnickoImeVlasnika:korisnickoImeVlasnika,
      korisnickoImeTuriste:korisnickoImeTuriste,
      vremeRezervacije:vremeRezervacije,
      odDatuma:odDatuma,
      doDatuma:doDatuma,
      brojOdraslih:brojOdraslih,
      brojDece:brojDece,
      cena:cena,
      nazivVikendice:nazivVikendice,
      mesto:mesto
    }
    return this.http.post<Rezervacija>(`${this.url}`, data);
  }

  getArhiva(korisnickoIme:string){
    return this.http.get<Rezervacija[]>(`${this.url}/get-arhiva`, {params:{korisnickoIme:korisnickoIme}});
  }

  getRezervacije(korisnickoIme:string){
    return this.http.get<Rezervacija[]>(`${this.url}/get-rezervacije`, {params:{korisnickoIme:korisnickoIme}});
  }

  updateKomentarOcena(idRezervacije: number, komentar: string, ocena: number) {
    const data = {
      idRezervacije:idRezervacije,
      komentar:komentar,
      ocena:ocena
    }
    return this.http.post<number>(`${this.url}/update-komentar-ocena`, data);
  }

  deleteRezervacija(idRezervacije: number){
    return this.http.get<boolean>(`${this.url}/delete-rezervacija/${idRezervacije}`);
  }

  getNeobradjeneRezervacije(korisnickoIme:string){
    return this.http.get<Rezervacija[]>(`${this.url}/get-neobradjene-rezervacije`, {params:{korisnickoIme:korisnickoIme}});
  }

  prihvatiRezervaciju(idRezervacije: number) {
    return this.http.post<number>(`${this.url}/prihvati-rezervaciju`, idRezervacije);
  }

  odbijRezervaciju(idRezervacije: number, razlog: string) {
  const params = new HttpParams()
    .set('idRezervacije', idRezervacije)
    .set('razlog', razlog);
  return this.http.post<number>(`${this.url}/odbij-rezervaciju`, null, { params });
}

}
