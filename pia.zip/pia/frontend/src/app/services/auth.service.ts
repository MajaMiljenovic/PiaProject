import { HttpClient } from '@angular/common/http';
import { inject, Injectable } from '@angular/core';
import { Korisnik } from '../models/Korisnik';
import { Podaci } from '../models/Podaci';
import { Admin } from '../models/Admin';

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  constructor() { }

  private http = inject(HttpClient)

  private url = "http://localhost:8080/auth";

  loginKorisnik(korisnickoIme:string, lozinka:string){
    const data = {
      korisnickoIme: korisnickoIme,
      lozinka: lozinka
    }
    return this.http.post<Korisnik>(`${this.url}/login-korisnik`, data);
  }

  loginAdmin(korisnickoIme:string, lozinka:string){
    const data = {
      korisnickoIme: korisnickoIme,
      lozinka: lozinka
    }
    return this.http.post<Admin>(`${this.url}/login-admin`, data);
  }

  registerKorisnik(korisnik:Korisnik){
    const formData = new FormData();
    formData.append("korisnickoIme", korisnik.korisnickoIme);
    formData.append("lozinka", korisnik.lozinka);
    formData.append("ime", korisnik.ime);
    formData.append("prezime", korisnik.prezime);
    formData.append("pol", korisnik.pol);
    formData.append("adresa", korisnik.adresa);
    formData.append("telefon", korisnik.telefon);
    formData.append("mejl", korisnik.mejl);
    formData.append("kartica", korisnik.kartica);
    const fajl = korisnik.slika ?? new File([""], "default.jpg");
    formData.append("slika", fajl, fajl.name);
    formData.append("tip", korisnik.tip);
    formData.append("aktivan", korisnik.aktivan);
    return this.http.post<Korisnik>(`${this.url}/register-korisnik`, formData)
  }

  getAllPodaci(){
    return this.http.get<Podaci>("http://localhost:8080/podaci")
  }

  changeLozinka(korisnickoIme:string, staraLozinka:string, novaLozinka:string){
    const formData = new FormData();
    formData.append("korisnickoIme", korisnickoIme);
    formData.append("staraLozinka", staraLozinka);
    formData.append("novaLozinka", novaLozinka);
    return this.http.post<Korisnik>(`${this.url}/change-lozinka`, formData)
  }

  changeLozinkaAdmin(korisnickoIme:string, staraLozinka:string, novaLozinka:string){
    const formData = new FormData();
    formData.append("korisnickoIme", korisnickoIme);
    formData.append("staraLozinka", staraLozinka);
    formData.append("novaLozinka", novaLozinka);
    return this.http.post<Admin>(`${this.url}/change-lozinka-admin`, formData)
  }

}
