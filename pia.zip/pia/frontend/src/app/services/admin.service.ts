import { inject, Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Admin } from '../models/Admin';
import { Korisnik } from '../models/Korisnik';
import { Vikendica } from '../models/Vikendica';

@Injectable({
  providedIn: 'root'
})
export class AdminService {

  constructor() { }

  private http = inject(HttpClient);
  private url = "http://localhost:8080/admin";

  prihvatiZahtev(korisnickoIme:string){
    return this.http.get<number>(`${this.url}/zahtevi/prihvati/${korisnickoIme}`);
  }

  odbijZahtev(korisnickoIme:string) {
    return this.http.get<number>(`${this.url}/zahtevi/odbij/${korisnickoIme}`);
  }

  getZahtevi(){
    return this.http.get<Korisnik[]>(`${this.url}/get-zahtevi`);
  }

  getAllVikendiceAdmin(){
    return this.http.get<Vikendica[]>(`${this.url}/get-all-vikendice-admin`);
  }

  getAllTuristi(){
    return this.http.get<Korisnik[]>(`${this.url}/get-all-turisti`)
  }

  getAllVlasnici(){
    return this.http.get<Korisnik[]>(`${this.url}/get-all-vlasnici`)
  }

  /*getLose(){
    return this.http.get<number[]>(`${this.url}/get-lose`)
  }*/


}
