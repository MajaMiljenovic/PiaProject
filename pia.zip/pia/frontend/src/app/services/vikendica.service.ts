import { HttpClient, HttpParams } from '@angular/common/http';
import { inject, Injectable } from '@angular/core';
import { Vikendica } from '../models/Vikendica';
import { Slika } from '../models/Slika';
import { Komentar } from '../models/Komentar';
import { Korisnik } from '../models/Korisnik';
import { from } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class VikendicaService {

  constructor() { }

  private http = inject(HttpClient)
  private url = 'http://localhost:8080/vikendica';

  getAllVikendice(select: string , naziv: string, mesto: string) {
    return this.http.get<Vikendica[]>(`${this.url}/get-all-vikendice`, {
      params: { select, naziv, mesto}
    });
  }

  getVikdendica(idVikendice: number) {
    return this.http.get<Vikendica>(`${this.url}/get-vikendica/${idVikendice}`);
  }

  obrisiVikendicu(idVikendice: number){
    return this.http.post<number>(`${this.url}/obrisi-vikendicu`, idVikendice);
  }

  getAllSlike(idVikendice: number) {
    return this.http.get<Slika[]>(`${this.url}/get-all-slike/${idVikendice}`)
  }

  getAllKomentari(idVikendice: number) {
    return this.http.get<Komentar[]>(`${this.url}/get-all-komentari/${idVikendice}`)
  }

  updateOcena(idVikendice: number) {
    alert("servis")
    const ocena = this.http.get<number>(`${this.url}/update-ocena/${idVikendice}`)
    alert(ocena + "iz servsa")
    return ocena;
  }

  getMojeVikendice(korisnickoIme: string) {
    return this.http.get<Vikendica[]>(`${this.url}/get-moje-vikendice`, { params: { korisnickoIme:korisnickoIme } });
  }

  updateNaziv(idVikendice: number, naziv: string) {
  const params = new HttpParams()
    .set('idVikendice', idVikendice.toString())
    .set('naziv', naziv);
  return this.http.post<number>(`${this.url}/update-naziv`, null, { params });
  }

  updateMesto(idVikendice: number, mesto: string) {
  const params = new HttpParams()
    .set('idVikendice', idVikendice.toString())
    .set('mesto', mesto);
  return this.http.post<number>(`${this.url}/update-mesto`, null, { params });
  }

  updateOpis(idVikendice: number, opis: string) {
    const params = new HttpParams()
      .set('idVikendice', idVikendice.toString())
      .set('opis', opis);
    return this.http.post<number>(`${this.url}/update-opis`, null, { params });
  }

  updateCenaLeto(idVikendice: number, cenaLeto: number) {
    const params = new HttpParams()
      .set('idVikendice', idVikendice.toString())
      .set('cenaLeto', cenaLeto.toString());
    return this.http.post<number>(`${this.url}/update-cenaLeto`, null, { params });
  }

  updateCenaZima(idVikendice: number, cenaZima: number) {
    const params = new HttpParams()
      .set('idVikendice', idVikendice.toString())
      .set('cenaZima', cenaZima.toString());
    return this.http.post<number>(`${this.url}/update-cenaZima`, null, { params });
  }

  updateTelefon(idVikendice: number, telefon: string) {
    const params = new HttpParams()
      .set('idVikendice', idVikendice.toString())
      .set('telefon', telefon);
    return this.http.post<number>(`${this.url}/update-telefon`, null, { params });
  }

  updateLat(idVikendice: number, lat: number) {
    const params = new HttpParams()
      .set('idVikendice', idVikendice.toString())
      .set('lat', lat.toString());
    return this.http.post<number>(`${this.url}/update-lat`, null, { params });
  }

  updateLng(idVikendice: number, lng: number) {
    const params = new HttpParams()
      .set('idVikendice', idVikendice.toString())
      .set('lng', lng.toString());
    return this.http.post<number>(`${this.url}/update-lng`, null, { params });
  }

  insertVikendica(vikendica: Vikendica){
    const data = {
      korisnickoImeVlasnika:vikendica.korisnickoImeVlasnika,
      naziv:vikendica.naziv,
      mesto:vikendica.mesto,
      opis:vikendica.opis,
      cenaLeto:vikendica.cenaLeto,
      cenaZima:vikendica.cenaZima,
      telefon:vikendica.telefon,
      lat:vikendica.lat,
      lng:vikendica.lng,
      ocena:vikendica.ocena
    }
    return this.http.post<number>(`${this.url}/insert-vikendica`, data);
  }

  insertGalerija(idVikendice:number, slike:File[]){
    const formData = new FormData()
    formData.append("idVikendice", idVikendice.toString());
    for(let i = 0; i < slike.length; i++){
      formData.append("slike", slike[i]);
    }
    return this.http.post<number>(`${this.url}/insert-galerija`, formData)
  }

  deleteSlika(slika:Slika){
    const data = {
      idSlike:slika.idSlike,
      idVikendice:slika.idVikendice,
      slika:slika.slika
    }
    return this.http.post<number>(`${this.url}/delete-slika`, data)
  }
  
}
