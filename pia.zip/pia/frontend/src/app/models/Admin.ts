export class Admin {
    korisnickoIme: string = ""
    lozinka: string = ""
    ime: string = ""
    prezime: string = ""
    mejl: string = ""
}