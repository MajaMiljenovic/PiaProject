export class Komentar {
    index = 0
    korisnickoIme = ""
    komentar = ""
    ocena = 0
}