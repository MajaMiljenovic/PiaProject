export class Korisnik {
    korisnickoIme: string = ""
    lozinka: string = ""
    ime: string = ""
    prezime: string = ""
    pol: string = ""
    adresa: string = ""
    telefon: string = ""
    mejl: string = ""
    slika!: File;
    kartica: string = ""
    tip: string = ""
    aktivan: string = "ne"
}