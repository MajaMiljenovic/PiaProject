export class Slika {
    idSlike: number = 0;
    idVikendice: number = 0;
    slika!: File;
}