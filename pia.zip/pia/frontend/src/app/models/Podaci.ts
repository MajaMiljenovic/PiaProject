export class Podaci {
    vikendiceCnt: number = 0;
    vlasniciCnt: number = 0;
    turistiCnt: number = 0;
    rezervacije24Cnt: number = 0;
    rezervacije7Cnt: number = 0;
    rezervacije30Cnt: number = 0;
}