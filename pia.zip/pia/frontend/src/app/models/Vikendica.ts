export class Vikendica{
    idVikendice:number = 0
    korisnickoImeVlasnika:string = ""
    naziv:string = ""
    mesto:string = ""
    opis:string = ""
    cenaLeto:number = 0.0
    cenaZima:number = 0.0
    telefon:string = ""
    lat:number = 0.0
    lng:number = 0.0
    ocena:number = 0.0
}