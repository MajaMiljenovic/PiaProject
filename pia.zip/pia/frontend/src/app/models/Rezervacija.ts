import { Timestamp } from "rxjs";

export class Rezervacija {
    idRezervacije: number = 0;
    idVikendice: number = 0;
    korisnickoImeVlasnika: string = "";
    korisnickoImeTuriste: string = "";
    vremeRezervacije!: Date;
    odDatuma!: Date;
    doDatuma!: Date;
    brojOdraslih: number = 0;
    brojDece: number = 0;
    cena: number = 0;
    nazivVikendice: string = ""
    komentar: string | null = null;
    ocena: number | null = null;
    mesto:string = ""

}